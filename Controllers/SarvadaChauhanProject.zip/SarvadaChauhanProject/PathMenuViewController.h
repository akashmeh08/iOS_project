//
//  PathMenuViewController.h
//  Mobiloitte
//

//

#import <UIKit/UIKit.h>

@interface PathMenuViewController : UIViewController
@property (weak, nonatomic) IBOutlet UIBarButtonItem *PathMenuButton;

@end
