//
//  SettingsViewController.m
//  Setting
//

//

#import "SettingsViewController.h"
//#import "CustomTableViewCell.h"
#import "SWRevealViewController.h"
#import "SettingCell.h"
#import "TermsAndConditionsViewController.h"
#import "AboutUsViewController.h"
#import "ChangePasswordViewController.h"
#import "MailComposerViewController.h"
#import "PrivacyPolicyViewController.h"

@interface SettingsViewController ()<UITableViewDataSource, UITableViewDelegate>
@property (strong, nonatomic) IBOutlet UIBarButtonItem *sidebarButton;


@end

@implementation SettingsViewController

- (void)viewDidLoad {
    [super viewDidLoad];
//self.navigationItem.title = @"Settings";
    SWRevealViewController *revealViewController =self.revealViewController;
    [self.navigationController setNavigationBarHidden:YES];
    if ( revealViewController )
    {
        NSLog(@"hkhdkjsf");
        [self.SettingMenuButton setTarget:self.revealViewController];
        [self.SettingMenuButton setAction: @selector( revealToggle: )];
        [self.view addGestureRecognizer:self.revealViewController.panGestureRecognizer];
    }
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    if(section == 0)
        return 1;
    else
        return 5;
}

-(CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    return 50;
}

-(NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    return 2;
}
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    SettingCell *cell = (SettingCell *)[tableView dequeueReusableCellWithIdentifier:@"settingsItem"];
    SettingCell *cell1 = (SettingCell *)[tableView dequeueReusableCellWithIdentifier:@"notifications"];
    if(cell == nil)
    {
        cell = [[SettingCell alloc]initWithStyle:UITableViewCellStyleDefault reuseIdentifier:@"settingsItem"];
    }
    if(cell1 == nil)
    {
        cell1 = [[SettingCell alloc]initWithStyle:UITableViewCellStyleDefault reuseIdentifier:@"notifications"];
    }
    if(indexPath.section == 0)
    {
        return cell1;
    }
    else
    {
        switch(indexPath.row)
        {
            case 0:
                cell.labelItemName.text = @"Terms & Conditions";
                break;
            case 1:
                cell.labelItemName.text = @"About Us";
                break;
            case 2:
                cell.labelItemName.text = @"Contact Us";
                break;
            case 3:
                cell.labelItemName.text = @"Change Password";
//                 [[self navigationController]setNavigationBarHidden:NO];
                break;
            case 4:
               cell.labelItemName.text = @"Privacy Policy";
                break;
    }
        cell1.selectionStyle =UITableViewCellSelectionStyleNone;
        cell.selectionStyle =UITableViewCellSelectionStyleNone;
    }
    return cell;
    
}
    


-(void)viewWillAppear:(BOOL)animated{
    [self.navigationController setNavigationBarHidden:YES];
}
-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    if(indexPath.section == 1)
    {
        switch (indexPath.row) {
                
            case 0:{
                
                UIStoryboard* storyboard = [UIStoryboard storyboardWithName:@"Main" bundle:nil];
                
                TermsAndConditionsViewController *controller = [storyboard instantiateViewControllerWithIdentifier:@"tandc"];
                
                [self.navigationController pushViewController:controller animated:YES ];
                
            }
                
                break;
                
            case 1:{
                UIStoryboard* storyboard = [UIStoryboard storyboardWithName:@"Main" bundle:nil];
                
               AboutUsViewController *controller = [storyboard instantiateViewControllerWithIdentifier:@"about"];
                
                
                
                [self.navigationController pushViewController:controller animated:YES ];
                
            }
                break;
            case 2:{
                
                    UIStoryboard *str = [UIStoryboard storyboardWithName:@"Main" bundle:nil];
                    MailComposerViewController *contr = [str instantiateViewControllerWithIdentifier:@"MailComposerViewController"];
                    [self.navigationController pushViewController:contr animated:YES];
                
            }
                
                break;
                
            case 3:{
                
                UIStoryboard* storyboard = [UIStoryboard storyboardWithName:@"Main" bundle:nil];
                
                ChangePasswordViewController *controller = [storyboard instantiateViewControllerWithIdentifier:@"change"];
                
                
                
                [self.navigationController pushViewController:controller animated:YES ];
                
            }
                
                break;
            case 4:{
                
                UIStoryboard* storyboard = [UIStoryboard storyboardWithName:@"Main" bundle:nil];
                
                PrivacyPolicyViewController *controller = [storyboard instantiateViewControllerWithIdentifier:@"privacyPolicyViewController"];
                
                
                [self.navigationController pushViewController:controller animated:YES ];
                
            }
                
                break;
                
                
                default:
                
                break;
                
        }}
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
//- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}

- (IBAction)pushForBack:(id)sender {
    UIStoryboard *str = [UIStoryboard storyboardWithName:@"Main" bundle:nil];
    SettingsViewController *contr = [str instantiateViewControllerWithIdentifier:@"Settings"];
    [self presentViewController:contr animated:YES completion:nil];
}

@end
