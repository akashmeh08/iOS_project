//
//  SettingsViewController.h
//  Setting
//

//

#import <UIKit/UIKit.h>

@interface SettingsViewController : UIViewController

@property (weak, nonatomic) IBOutlet UIBarButtonItem *SettingMenuButton;


@end
