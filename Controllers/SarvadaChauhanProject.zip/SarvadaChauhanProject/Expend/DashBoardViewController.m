//
//  DashBoardViewController.m
//  Mobiloitte
//
//  Created by Mobiloitte on 18/03/17.
//  Copyright © 2017 Mobiloitte. All rights reserved.
//

#import "DashBoardViewController.h"
#import "DashBoardCollectionViewCell.h"
#import "SWRevealViewController.h"

#import <QuartzCore/QuartzCore.h>

@interface DashBoardViewController ()<UICollectionViewDelegate,UICollectionViewDataSource>

@end

@implementation DashBoardViewController

{
    NSArray *dashBoardImageList;
}
- (void)viewDidLoad {
    [super viewDidLoad];
    self.navigationItem.title = @"Dashboard";
    [[self navigationController]setNavigationBarHidden:YES];
    // Do any additional setup after loading the view.
    
    SWRevealViewController *revealViewController =self.revealViewController; //[[SWRevealViewController alloc]init];
    if ( revealViewController )
    {
        NSLog(@"hkhdkjsf");
        [self.dashBoardMenuButton setTarget:self.revealViewController];
        [self.dashBoardMenuButton setAction: @selector( revealToggle: )];
        [self.view addGestureRecognizer:self.revealViewController.panGestureRecognizer];
    }
    dashBoardImageList = [[NSArray alloc]initWithObjects:@"images.png",@"img1.jpg",@"img2.jpg",@"img3.jpg",@"img4.jpg",@"img5.jpg",@"img6.jpg",@"images-1.jpg",@"images2.jpg",@"images3.jpg",@"images4.jpg",@"images5.jpg",@"images6.jpg",@"images7.jpg",@"images8.png",@"images9.png",nil];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


- (NSInteger)collectionView:(UICollectionView *)collectionView numberOfItemsInSection:(NSInteger)section{
    return 15;//[dashBoardImageList count];
}

// The cell that is returned must be retrieved from a call to -dequeueReusableCellWithReuseIdentifier:forIndexPath:
- (__kindof UICollectionViewCell *)collectionView:(UICollectionView *)collectionView cellForItemAtIndexPath:(NSIndexPath *)indexPath{
    
    UICollectionViewCell *cell = (UICollectionViewCell*) [collectionView dequeueReusableCellWithReuseIdentifier:@"Cell" forIndexPath:indexPath];
    UIImageView *recipeImageView = (UIImageView *)[cell viewWithTag:100];
    recipeImageView.image = [UIImage imageNamed:[dashBoardImageList objectAtIndex:indexPath.row]];
    cell.backgroundView = [[UIImageView alloc] initWithImage:[UIImage imageNamed:@"photo-frame.png"]];
    [self.view addSubview:recipeImageView];
    cell.backgroundColor=[UIColor colorWithPatternImage:[UIImage imageNamed:[dashBoardImageList objectAtIndex:indexPath.row]]];
//    [UIImageView.layer setBorderColor: [[UIColor blackColor] CGColor]];
//    [UIImageView.layer setBorderWidth: 2.0];
    return cell;
    
 }

- (void)collectionView:(UICollectionView *)collectionView didSelectItemAtIndexPath:(NSIndexPath *)indexPath
{
   
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

- (IBAction)DashBoardIcon:(id)sender {
}
@end
