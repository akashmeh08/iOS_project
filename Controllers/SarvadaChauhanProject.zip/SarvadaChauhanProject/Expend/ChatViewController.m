//
//  ChatViewController.m
//  NewScreensTest
//
//  Created by Ram Chandra on 18/03/17.
//  Copyright © 2017 Ram Chandra. All rights reserved.
//

#import "ChatViewController.h"

#import "ChatTableViewCell.h"
#import "SWRevealViewController.h"

@interface ChatViewController ()<UITableViewDelegate, UITableViewDataSource, UITextFieldDelegate>
{
    NSArray *receivedMsgs;
    NSUInteger count;
    NSString *sentMsg;
}
@property (weak, nonatomic) IBOutlet UITableView *chatTableView;
@property (weak, nonatomic) IBOutlet UIButton *sendButton;
@property (weak, nonatomic) IBOutlet UITextField *typingField;


@end

@implementation ChatViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    self.navigationItem.title = @"Chat";
    count = 0;
    receivedMsgs = [[NSArray alloc]initWithObjects:@"Hello", @"Hi", @"I am XCode", @"May I Know who you actually are?", @"Lets Be Friends", @"Nice To Meet You", nil];
    // Do any additional setup after loading the view.
   SWRevealViewController *revealViewController =self.revealViewController; 
    if ( revealViewController )
    {
        NSLog(@"hkhdkjsf");
        [self.ChatMenuButton setTarget:self.revealViewController];
        [self.ChatMenuButton setAction: @selector( revealToggle: )];
        [self.view addGestureRecognizer:self.revealViewController.panGestureRecognizer];
       
        
        UITapGestureRecognizer *tap = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(dismissKeyboard)];
        
        [self.view addGestureRecognizer:tap];
    }
}




-(void)dismissKeyboard
{
    [_typingField resignFirstResponder];
}
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}
-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return 12;
}
-(CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    return 80;
}
//-(BOOL)textFieldShouldEndEditing:(UITextField *)textField
//{
//    sentMsg = textField.text;
//    return YES;
//}
-(BOOL)textFieldShouldReturn:(UITextField *)textField{
    if(textField.returnKeyType == UIReturnKeyDone){
        
        [self.view endEditing:YES];
    }
    
    return YES;
}
- (IBAction)msgSent:(id)sender {
   _typingField.text=@"";
    
}
-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    ChatTableViewCell *cell1 = (ChatTableViewCell *)[tableView dequeueReusableCellWithIdentifier:@"cell1"];
    ChatTableViewCell *cell2 = (ChatTableViewCell *)[tableView dequeueReusableCellWithIdentifier:@"cell2"];
    
    switch (indexPath.row%2) {
        case 0:
        {
        
            return cell1;
            break;
        }
        case 1:
        {
            
            return cell2;
            break;
        }
        case 2:
        {
            
            return cell1;
            break;
        }
        case 3:
        {
            
            return cell2;
            break;
        }
        case 4:
        {
            
            return cell1;
            break;
        }
        case 5:
        {
            
            return cell2;
            break;
        }
        case 6:
        {
            
            return cell1;
            break;
        }
        case 7:
        {
            
            return cell2;
            break;
        }
        case 8:
        {
            
            return cell1;
            break;
        }
        case 9:
        {
            
            return cell2;
            break;
        }
        case 10:
        {
            
            return cell1;
            break;
        }
        case 11:
        {
            
            return cell2;
            break;
        }
            
            
            
    }
    return nil;
}
-(void)textFieldDidEndEditing:(UITextField *)textField{
    self.view.frame = CGRectOffset(self.view.frame, 0, +271);
}


-(void)resignKB: (UITapGestureRecognizer *)sender{
    [self.view endEditing:YES];
}
-(void)viewWillAppear:(BOOL)animated {
    [super viewWillAppear:animated];
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(keyboardWillShow:) name:UIKeyboardWillShowNotification object:nil];
//    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(keyboardWillHide:) name:UIKeyboardWillHideNotification object:nil];
}

- (void)viewWillDisappear:(BOOL)animated {
    [super viewWillDisappear:animated];
    [[NSNotificationCenter defaultCenter] removeObserver:self name:UIKeyboardWillShowNotification object:nil];
    [[NSNotificationCenter defaultCenter] removeObserver:self name:UIKeyboardWillHideNotification object:nil];
}

#pragma mark - keyboard movements
- (void)keyboardWillShow:(NSNotification *)notification
{
    CGSize keyboardSize = [[[notification userInfo] objectForKey:UIKeyboardFrameBeginUserInfoKey] CGRectValue].size;
    
    [UIView animateWithDuration:0.3 animations:^{
        CGRect f = self.view.frame;
        f.origin.y = -keyboardSize.height;
        self.view.frame = f;
    }];
}

//-(void)keyboardWillHide:(NSNotification *)notification
//{
//    [UIView animateWithDuration:0.3 animations:^{
//        CGRect f = self.view.frame;
//        f.origin.y = 0.0f;
//        self.view.frame = f;
//    }];
//}
//-(void)touchesBegan:(NSSet *)touches withEvent:(nullable UIEvent *)event{
//    [self.view endEditing:YES];
//}


/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
