//
//  TPViewController.m
//  TPFloatRatingViewDemo
//
//  Created by Glen Yi on 2/27/2014.
//  Copyright (c) 2014 Glen. All rights reserved.
//

#import "TPViewController.h"
#import "SWRevealViewController.h"

@interface TPViewController ()
@property (weak, nonatomic) IBOutlet UIImageView *image1;
@property (weak, nonatomic) IBOutlet UIScrollView *scrollView;
@property (weak, nonatomic) IBOutlet UITextView *textView1;
@property (weak, nonatomic) IBOutlet UILabel *textCount;

@end

@implementation TPViewController

- (void)viewDidLoad
{
    [super viewDidLoad];
	// Do any additional setup after loading the view, typically from a nib.
      self.navigationItem.title = @"Rate";
    self.ratingView.delegate = self;
    self.ratingView.emptySelectedImage = [UIImage imageNamed:@"StarEmpty"];
    self.ratingView.fullSelectedImage = [UIImage imageNamed:@"StarFull"];
    self.ratingView.contentMode = UIViewContentModeScaleAspectFill;
    self.ratingView.maxRating = 5;
    self.ratingView.minRating = 1;
    self.ratingView.rating = 2.5;
    self.ratingView.editable = YES;
    self.ratingView.halfRatings = YES;
    self.ratingView.floatRatings = NO;
    
    self.ratingLabel.text = [NSString stringWithFormat:@"%.2f", self.ratingView.rating];
    self.liveLabel.text = [NSString stringWithFormat:@"%.2f", self.ratingView.rating];
    
    self.segmentedControl.selectedSegmentIndex = 1;
   _segmentedControl.hidden=YES;
    _liveLabel.hidden=YES;
    _ratingLabel.hidden=YES;
    
   // _textView1.layer.cornerRadius = 5;
    _textView1.layer.borderColor =[[UIColor blackColor] CGColor];
    _textView1.layer.borderWidth = 1;
    
    self.image1.clipsToBounds = YES;
    //_image1.layer.borderWidth=1;
//    _image1.layer.cornerRadius = 50;
    SWRevealViewController *revealViewController =self.revealViewController;
    if ( revealViewController )
    {
        NSLog(@"hkhdkjsf");
        [self.RatingMenuButton setTarget:self.revealViewController];
        [self.RatingMenuButton setAction: @selector( revealToggle: )];
        [self.view addGestureRecognizer:self.revealViewController.panGestureRecognizer];
    }
    }

- (BOOL)textView:(UITextView *)textView shouldChangeTextInRange:(NSRange)range replacementText:(NSString *)text
{
    NSInteger newTextLength = [_textView1.text length] - range.length + [text length];
    
    if (newTextLength > 340)
    {
        
        return NO;
    }_textCount.text = [NSString stringWithFormat:@"%li", 340-newTextLength];
    
    return YES;
    
}


- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

#pragma mark - TPFloatRatingViewDelegate

- (void)floatRatingView:(TPFloatRatingView *)ratingView ratingDidChange:(CGFloat)rating
{
    self.ratingLabel.text = [NSString stringWithFormat:@"%.2f", rating];
}

- (void)floatRatingView:(TPFloatRatingView *)ratingView continuousRating:(CGFloat)rating
{
    self.liveLabel.text = [NSString stringWithFormat:@"%.2f", rating];
}

- (IBAction)controlChange:(id)sender
{
    UISegmentedControl *control = (UISegmentedControl *)sender;
    
    self.ratingView.halfRatings = control.selectedSegmentIndex==1? YES:NO;
    self.ratingView.floatRatings = control.selectedSegmentIndex==2? YES:NO;
}
- (void)viewWillAppear:(BOOL)animated {
    [super viewWillAppear:animated];
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(keyboardWillShow:) name:UIKeyboardWillShowNotification object:nil];
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(keyboardWillHide:) name:UIKeyboardWillHideNotification object:nil];
}

- (void)viewWillDisappear:(BOOL)animated {
    [super viewWillDisappear:animated];
    [[NSNotificationCenter defaultCenter] removeObserver:self name:UIKeyboardWillShowNotification object:nil];
    [[NSNotificationCenter defaultCenter] removeObserver:self name:UIKeyboardWillHideNotification object:nil];
}

#pragma mark - keyboard movements
- (void)keyboardWillShow:(NSNotification *)notification
{
    CGSize keyboardSize = [[[notification userInfo] objectForKey:UIKeyboardFrameBeginUserInfoKey] CGRectValue].size;
    
    [UIView animateWithDuration:0.3 animations:^{
        CGRect f = self.view.frame;
        f.origin.y = -keyboardSize.height;
        self.view.frame = f;
    }];
}

-(void)keyboardWillHide:(NSNotification *)notification
{
    [UIView animateWithDuration:0.3 animations:^{
        CGRect f = self.view.frame;
        f.origin.y = 0.0f;
        self.view.frame = f;
    }];
}
@end
