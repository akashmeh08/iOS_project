//
//  DashBoardCollectionViewCell.m
//  Mobiloitte
//
//  Created by Mobiloitte on 18/03/17.
//  Copyright © 2017 Mobiloitte. All rights reserved.
//

#import "DashBoardCollectionViewCell.h"

@implementation DashBoardCollectionViewCell

@end
