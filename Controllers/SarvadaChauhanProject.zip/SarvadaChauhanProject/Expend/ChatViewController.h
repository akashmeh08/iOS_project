//
//  ChatViewController.h
//  NewScreensTest
//
//  Created by Sarvada Chauhan on 18/03/17.
//  Copyright © 2017 Sarvada Chauhan. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ChatViewController : UIViewController
@property (weak, nonatomic) IBOutlet UIBarButtonItem *ChatMenuButton;

@end
