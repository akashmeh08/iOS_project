//
//  MUserInfo.m
//  Mobiloitte
//

//  Copyright © 2017 Mobiloitte. All rights reserved.
//

#import "MUserInfo.h"


@implementation MUserInfo



@end
