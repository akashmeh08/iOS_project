//
//  BoopsViewController.m
//  Mobiloitte
//
//  Created by Mobiloitte on 20/03/17.
//  Copyright © 2017 Mobiloitte. All rights reserved.
//

#import "BoopsViewController.h"
#import "SWRevealViewController.h"
#import "BoopsTableViewCell.h"
#import "BoopsCollectionViewCell.h"
@interface BoopsViewController ()<UITableViewDelegate,UITableViewDataSource,UICollectionViewDelegate,UICollectionViewDataSource>

@end

@implementation BoopsViewController
{
    NSArray *dashBoardImageList;
}
- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    SWRevealViewController *revealViewController =self.revealViewController; //[[SWRevealViewController alloc]init];
    if ( revealViewController )
    {
        NSLog(@"hkhdkjsf");
        [self.barButton setTarget:self.revealViewController];
        [self.barButton setAction: @selector( revealToggle: )];
       // [self.view addGestureRecognizer:self.revealViewController.panGestureRecognizer];
    }
    dashBoardImageList = [[NSArray alloc]initWithObjects:@"img1.jpg",@"img3.jpg",@"img4.jpg",@"img5.jpg",@"img6.jpg",@"img3.jpg",@"img4.jpg",@"img5.jpg",@"img6.jpg",@"images8-1.jpg",@"images7.jpg",@"img1.jpg",@"img3.jpg",@"img1.jpg",@"img3.jpg",@"img4.jpg",@"img5.jpg",@"img6.jpg",@"img3.jpg",@"img4.jpg",@"img5.jpg",@"img6.jpg",@"images8-1.jpg",@"images7.jpg",nil];
    
    //_boopstableView.layer.borderWidth = 2;
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    
    return 10;
}

// Row display. Implementers should *always* try to reuse cells by setting each cell's reuseIdentifier and querying for available reusable cells with dequeueReusableCellWithIdentifier:
// Cell gets various attributes set automatically based on table (separators) and data source (accessory views, editing controls)

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath;
{
    BoopsTableViewCell *cell = (BoopsTableViewCell*)[tableView dequeueReusableCellWithIdentifier:@"Cell"];
    
    return cell;
}
- (NSInteger)collectionView:(UICollectionView *)collectionView numberOfItemsInSection:
(NSInteger)section
{
    return [dashBoardImageList count];
}

// The cell that is returned must be retrieved from a call to -dequeueReusableCellWithReuseIdentifier:forIndexPath:
- (__kindof UICollectionViewCell *)collectionView:(UICollectionView *)collectionView cellForItemAtIndexPath:(NSIndexPath *)indexPath
{
     BoopsCollectionViewCell *cell = (BoopsCollectionViewCell*) [collectionView dequeueReusableCellWithReuseIdentifier:@"Cell" forIndexPath:indexPath];
    cell.boopsImageView.image = [UIImage imageNamed:[dashBoardImageList objectAtIndex:indexPath.row]];
    cell.boopsImageView.layer.borderWidth = 1;
    cell.boopsImageView.layer.borderColor = [UIColor blackColor].CGColor;
    cell.layer.borderColor = [UIColor greenColor].CGColor;
    return cell;
}


@end
