//
//  BoopsCollectionViewCell.m
//  Mobiloitte
//
//  Created by Mobiloitte on 20/03/17.
//  Copyright © 2017 Mobiloitte. All rights reserved.
//

#import "BoopsCollectionViewCell.h"

@implementation BoopsCollectionViewCell

@end
