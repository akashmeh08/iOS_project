//
//  TermsAndConditionsViewController.m
//  Mobiloitte
//
//  Created by Sarvada Chauhan on 20/03/17.
//  Copyright © 2017 Mobiloitte. All rights reserved.
//
#import "TermsAndConditionsViewController.h"

@interface TermsAndConditionsViewController ()
@property (weak, nonatomic) IBOutlet UITextView *textViewOffset;

@end

@implementation TermsAndConditionsViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    self.navigationItem.title = @"Terms & Conditions";
     [[self navigationController]setNavigationBarHidden:NO];
    
    // Do any additional setup after loading the view.
}
- (void)viewDidLayoutSubviews
{
    [super viewDidLayoutSubviews];
    [self.textViewOffset setContentOffset:CGPointZero animated:NO];
   // [self.aboutUsTextView setContentOffset:CGPointZero animated:NO];
  //  [self.contactUsTextView setContentOffset:CGPointZero animated:NO];
   // [self.privacyTextView setContentOffset:CGPointZero animated:NO];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}
//- (void)scrollViewDidScroll:(UIScrollView *)scrollView{
    
   // if (scrollView.contentOffset.y
    //self.TextView.frame.size.height*-1 ) {
        //[scrollView //setContentOffset:CGPointMake(scrollView.contentOffset.x,   self.TextView.frame.size.height*-1)];
        
    

/*
 #pragma mark - Navigation
 
 // In a storyboard-based application, you will often want to do a little preparation before navigation
 - (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
 // Get the new view controller using [segue destinationViewController].
 // Pass the selected object to the new view controller.
 }
 */

@end
