//
//  ChangePasswordViewController.h
//  Mobiloitte
//
//  Created by Sarvada Chauhan on 20/03/17.
//  Copyright © 2017 Mobiloitte. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ChangePasswordViewController : UIViewController

@end
