//
//  SignUpViewController.h
//  Mobiloitte
//
//  Copyright © 2017 Mobiloitte. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface SignUpViewController : UIViewController
@property (weak, nonatomic) IBOutlet UITextView *biographyTextView;
- (IBAction)onSubmitBtnTouch:(id)sender;

@end
