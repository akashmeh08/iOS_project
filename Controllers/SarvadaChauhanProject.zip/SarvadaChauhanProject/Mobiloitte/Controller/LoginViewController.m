//
//  LoginViewController.m
//  Mobiloitte
//

//

#import "LoginViewController.h"
#import "Utility.h"
#import "SignUpViewController.h"
#import "MUserInfo.h"
#import "HomeViewController.h"
#import "SWRevealViewController.h"

@interface LoginViewController ()
{
    int state;
}

@end

@implementation LoginViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
       //self.navigationItem.title = @"Login";
   [[self navigationController]setNavigationBarHidden:YES];
    [self customInit];
   
    state=0;
  
}
//-(void)viewWillAppear:(BOOL)animated{
//}
-(BOOL)textFieldShouldReturn:(UITextField *)textField
{
    if(textField.returnKeyType==UIReturnKeyNext)
    {
        UITextField *tf=(UITextField *)[self.view viewWithTag:textField.tag+1];
        [tf becomeFirstResponder];
    }
    else
    {
        [self.view endEditing:YES];
    }
    return YES;
    
}
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


#pragma mark - Helper Methods
-(void)customInit {
    
    
    //   self.navigationItem.leftBarButtonItem =
    
    //    self.navigationController?.navigationBar.backIndicatorImage = UIImage(named: "HomeLeft@2x")
    //    self.navigationController?.navigationBar.backIndicatorTransitionMaskImage = UIImage(named: "HomeLeft@2x");
    //
    
    
    [_emailTextField setKeyboardType:UIKeyboardTypeEmailAddress];
    UITapGestureRecognizer *tap = [[UITapGestureRecognizer alloc]   initWithTarget:self action:@selector(dismissKeyboard)];
    [self.view addGestureRecognizer:tap];  //to dismiss keyboard
}

-(void)dismissKeyboard {
    [self.view endEditing:YES];
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/
-(void)textFieldDidBeginEditing:(UITextField *)textField
{
    //  textField.autocapitalizationType = UITextAutocapitalizationTypeWords ;
    
    if(textField.frame.origin.y)
        [self animateTextField:textField up:YES];
     
}

- (void)textFieldDidEndEditing:(UITextField *)textField
{
    [self animateTextField:textField up:NO];
    
}
-(void)animateTextField:(UITextField*)textField up:(BOOL)up
{
    
    
    int movementDistance = -90; // tweak as needed
    
    const float movementDuration = 0.3f; // tweak as needed
    
    int movement = (up ? movementDistance : -movementDistance);
    
    [UIView beginAnimations: @"animateTextField" context: nil];
    [UIView setAnimationBeginsFromCurrentState: YES];
    [UIView setAnimationDuration: movementDuration];
    self.view.frame = CGRectOffset(self.view.frame, 0, movement);
    [UIView commitAnimations];
}

- (void)viewWillAppear:(BOOL)animated {
    [self.navigationController setNavigationBarHidden:YES];
    [super viewWillAppear:animated];
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(keyboardWillShow:) name:UIKeyboardWillShowNotification object:nil];
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(keyboardWillHide:) name:UIKeyboardWillHideNotification object:nil];
}

- (void)viewWillDisappear:(BOOL)animated {
    [super viewWillDisappear:animated];
    [[NSNotificationCenter defaultCenter] removeObserver:self name:UIKeyboardWillShowNotification object:nil];
    [[NSNotificationCenter defaultCenter] removeObserver:self name:UIKeyboardWillHideNotification object:nil];
}

#pragma mark - keyboard movements
- (void)keyboardWillShow:(NSNotification *)notification
{
   // CGSize keyboardSize = [[[notification userInfo] objectForKey:UIKeyboardFrameBeginUserInfoKey] CGRectValue].size;
    
    [UIView animateWithDuration:0.3 animations:^{
        CGRect f = self.view.frame;
        f.origin.y = -100;
        self.view.frame = f;
    }];
}

-(void)keyboardWillHide:(NSNotification *)notification
{
    [UIView animateWithDuration:0.3 animations:^{
        CGRect f = self.view.frame;
        f.origin.y = -100;
        self.view.frame = f;
    }];
}

- (IBAction)onLoginBtnTouch:(id)sender {
    
    Utility *utility=[[Utility alloc]init];
    NSString *email=(NSString*)_emailTextField.text;
    NSString *password=(NSString*)_passwordTextField.text;
    NSString *result=[utility isValidate:email :password];
    NSLog(@"result = %@",result);
    if([result isEqualToString:@"Success"])
    {
        UIStoryboard *storyboard = [UIStoryboard storyboardWithName:@"Main" bundle:nil];
        SWRevealViewController *controller = [storyboard instantiateViewControllerWithIdentifier:@"HomeViewController"];
        [self.navigationController pushViewController:controller animated:YES];

        
    }
    else
    {
        UIAlertController *alert = [UIAlertController alertControllerWithTitle:nil message:result preferredStyle:UIAlertControllerStyleAlert ];
        
        UIAlertAction *ok = [UIAlertAction actionWithTitle:@"Ok" style:UIAlertActionStyleDefault handler:nil];
        
        [alert addAction:ok];
        [self presentViewController:alert animated:YES completion:nil];
        
    }
}

- (IBAction)onSignUpBtnTouch:(id)sender {
    
    UIStoryboard* storyboard = [UIStoryboard storyboardWithName:@"Main" bundle:nil];
    SignUpViewController * controller = [storyboard instantiateViewControllerWithIdentifier:@"SignUpViewController"];
    
    [self.navigationController pushViewController:controller animated:YES ];
}


- (BOOL)textField:(UITextField *)textField shouldChangeCharactersInRange:(NSRange)range replacementString:(NSString *)string
{
   /* if (textField.text.length >=50 && range.length == 0)
    {
        return NO; // return NO to not change text
    }
    else
    {return YES;}
}
*/
    if(string.length > 64){
        string = [string substringToIndex:64];
        textField.text = string;
        return NO;
    }
    if(textField.text.length + string.length >=64 && range.length == 0)
    {
        return NO;
    }
    // {return YES;}
    else{
        
        return YES;
    }
}
- (IBAction)onCheckboxTouch:(id)sender {
    if(state==0)
    {
        state=1;
        
        [_checkboxBtn setBackgroundImage:[UIImage imageNamed:@"checked-checkbox-512.png"] forState:UIControlStateNormal];
        
    }
    else{
        
        state=0;
        [_checkboxBtn setBackgroundImage:[UIImage imageNamed:@"checkbox1.png"] forState:UIControlStateNormal];
    }
}
@end
