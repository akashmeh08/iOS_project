//
//  SignUpVC.h
//  Mobiloitte
//
//  Copyright © 2017 Mobiloitte. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface SignUpVC : UIViewController
@property (weak, nonatomic) IBOutlet UIScrollView *signupScrollView;

@end
