//
//  ProfileInfoViewController.m
//  Mobiloitte
//
//  Created by Akash sharma on 16/03/17.
//  Copyright © 2017 Mobiloitte. All rights reserved.
//

#import "ProfileInfoViewController.h"
#import "MUserInfo.h"

@interface ProfileInfoViewController ()

@property (weak, nonatomic) IBOutlet UIImageView *profileInfo;
@property (weak, nonatomic) IBOutlet UILabel *userDob;
@property (weak, nonatomic) IBOutlet UILabel *userMob;

@end

@implementation ProfileInfoViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    self.navigationItem.title = @"Profile";
    // Do any additional setup after loading the view.
   [[self navigationController]setNavigationBarHidden:NO]; 
  
     [self customInit];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}
-(void)customInit
{
    
    
    self.profileInfo.clipsToBounds = YES;
    _profileInfo.layer.borderWidth=1;
    _profileInfo.layer.cornerRadius = 50;
    
    int  rowNumber = [_userInfo.rowIndex intValue];
    self.navigationItem.title = [_userInfo.nameArray objectAtIndex:rowNumber];
   
    _profileInfo.image=[UIImage imageNamed:[_userInfo.imageView1 objectAtIndex:rowNumber]];
    _userDob.text=[_userInfo.dobArray objectAtIndex:rowNumber];
    _userMob.text=[_userInfo.phoneNo objectAtIndex:rowNumber];
    
    
}

- (void)viewWillAppear:(BOOL)animated {
    [super viewWillAppear:animated];
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(keyboardWillShow:) name:UIKeyboardWillShowNotification object:nil];
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(keyboardWillHide:) name:UIKeyboardWillHideNotification object:nil];
}

- (void)viewWillDisappear:(BOOL)animated {
    [super viewWillDisappear:animated];
    [[NSNotificationCenter defaultCenter] removeObserver:self name:UIKeyboardWillShowNotification object:nil];
    [[NSNotificationCenter defaultCenter] removeObserver:self name:UIKeyboardWillHideNotification object:nil];
}

#pragma mark - keyboard movements
- (void)keyboardWillShow:(NSNotification *)notification
{
    CGSize keyboardSize = [[[notification userInfo] objectForKey:UIKeyboardFrameBeginUserInfoKey] CGRectValue].size;
    
    [UIView animateWithDuration:0.3 animations:^{
        CGRect f = self.view.frame;
        f.origin.y = -keyboardSize.height;
        self.view.frame = f;
    }];
}

-(void)keyboardWillHide:(NSNotification *)notification
{
    [UIView animateWithDuration:0.3 animations:^{
        CGRect f = self.view.frame;
        f.origin.y = 0.0f;
        self.view.frame = f;
    }];
}
#pragma mark- Keyboard Diasappear Method
-(void)touchesBegan:(NSSet *)touches withEvent:(nullable UIEvent *)event{
    [self.view endEditing:YES];
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
