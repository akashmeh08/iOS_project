//
//  LoginViewController.h
//  Mobiloitte
//

//

#import <UIKit/UIKit.h>

@interface LoginViewController : UIViewController
/*- (IBAction)onCheckboxTouch:(id)sender;
- (IBAction)onLoginBtnTouch:(id)sender;
@property (weak, nonatomic) IBOutlet UITextField *emailTextField;
@property (weak, nonatomic) IBOutlet UITextField *passwordTextField;
*/
@property (weak, nonatomic) IBOutlet UITextField *emailTextField;

@property (weak, nonatomic) IBOutlet UITextField *passwordTextField;
- (IBAction)onCheckboxTouch:(id)sender;
- (IBAction)onLoginBtnTouch:(id)sender;
- (IBAction)onSignUpBtnTouch:(id)sender;
@property (weak, nonatomic) IBOutlet UIButton *checkboxBtn;

@end
