//
//  SegmentViewController.m
//  Mobiloitte
//
//  Created by SarvadaChauhan on 17/03/17.
//  Copyright © 2017 Mobiloitte. All rights reserved.
//

#import "SegmentViewController.h"

@interface SegmentViewController ()<UITableViewDelegate,UITableViewDataSource>
{
    NSArray *listArray;
}

@end

@implementation SegmentViewController
@synthesize segmentBtn;
@synthesize mapView = _mapView;


- (void)viewDidLoad {
    [super viewDidLoad];
    self.navigationItem.title = @"List & Map";
    // Do any additional setup after loading the view.

    self.navigationController.navigationBar.topItem.title = @"Back";
    self.navigationItem.title = @"List & Map";
    [[self navigationController]setNavigationBarHidden:NO];
    [segmentBtn addTarget:self action:@selector(segmentedControlChangedValue:) forControlEvents:UIControlEventValueChanged];
    self.navigationItem.title = @"List & Map";
    listArray = [[NSArray alloc]initWithObjects:@"Raj Narayan Sir",@"Sarvada Chauhan",@"Anshu aggarwal",@"Samiksha Vashishtha",@"Anjali Sharma", nil];
  
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

-(void)segmentedControlChangedValue:forControlEvents
{
    NSLog(@"%ld", (long)self.segmentBtn.selectedSegmentIndex);
    if(self.segmentBtn.selectedSegmentIndex == 1)
    {
        _listTableView.hidden=YES;
        _mapView.hidden=NO;
    }
    else
    {
        _listTableView.hidden=false;
       _mapView.hidden=true;
    }
}



- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    return [listArray count];
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    
    UITableViewCell *cell=(UITableViewCell *)[tableView dequeueReusableCellWithIdentifier:@"cell"];
    if (cell == nil) {
        cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:@"cell"];
    }
    
    cell.textLabel.text = [listArray objectAtIndex:indexPath.row];
    return cell;
    
}

@end
