//
//  NavigationViewController.m
//  Mobiloitte
//
//  Copyright © 2017 Mobiloitte. All rights reserved.
//

#import "NavigationViewController.h"
#import "TPViewController.h"
#import "EandCViewController.h"
#import "PathMenuViewController.h"
#import "SettingsViewController.h"
#import "DashBoardViewController.h"
#import "HomeViewController.h"
#import "ChatViewController.h"
#import "CarouselViewController.h"
#import "CKViewController.h"
#import "BoopsViewController.h"
#import "MailComposerViewController.h"
#import "PrivacyPolicyViewController.h"
@interface NavigationViewController ()<UITableViewDelegate,UITableViewDataSource>

@end

@implementation NavigationViewController
{
    NSArray *menu;
}
- (void)viewDidLoad {
    [super viewDidLoad];
    menu= @[@"Home",@"Dashboard",@"Chat",@"Settings",@"Graphs",@"Rate Us",@"Calendar",@"Path Menu",@"Boops",@"Carousel",@"Expand-Collapse"];
    // Do any additional setup after loading the view.
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return [menu count];
}

// Row display. Implementers should *always* try to reuse cells by setting each cell's reuseIdentifier and querying for available reusable cells with dequeueReusableCellWithIdentifier:
// Cell gets various attributes set automatically based on table (separators) and data source (accessory views, editing controls)

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"Cell"];
    
    if (cell==nil) {
        cell = [[UITableViewCell alloc]initWithStyle:UITableViewCellStyleSubtitle reuseIdentifier:@"Cell"];
        
    }
    cell.textLabel.text = [menu objectAtIndex:indexPath.row];
    return cell;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    SWRevealViewController *swvc = self.revealViewController;
    if(indexPath.row==0)
    {
        UIStoryboard *storyboard = [UIStoryboard storyboardWithName:@"Main" bundle:nil];
        HomeViewController *controller = [storyboard instantiateViewControllerWithIdentifier:@"HomeViewController"];
//        [self.navigationController pushViewController:controller animated:YES];
        [swvc setFrontViewController:controller animated:NO];
        [swvc revealToggleAnimated:YES];
//        [[self navigationController]setNavigationBarHidden:NO];
    }
    
    if(indexPath.row==2)
    {
        UIStoryboard *storyboard = [UIStoryboard storyboardWithName:@"Main" bundle:nil];
        ChatViewController *controller = [storyboard instantiateViewControllerWithIdentifier:@"Chat"];
//        [self.navigationController pushViewController:controller animated:YES];
        [swvc setFrontViewController:controller animated:NO];
        [swvc revealToggleAnimated:YES];
    }
    if(indexPath.row==1)
    {
        UIStoryboard *storyboard = [UIStoryboard storyboardWithName:@"Main" bundle:nil];
        DashBoardViewController *controller = [storyboard instantiateViewControllerWithIdentifier:@"DashBoardViewController"];
//        [self.navigationController pushViewController:controller animated:YES];
        [swvc setFrontViewController:controller animated:NO];
        [swvc revealToggleAnimated:YES];
    }
    if(indexPath.row==5)
    {
        UIStoryboard *storyboard = [UIStoryboard storyboardWithName:@"Main" bundle:nil];
        TPViewController *controller = [storyboard instantiateViewControllerWithIdentifier:@"TPViewController"];
//        [self.navigationController pushViewController:controller animated:YES];
        [swvc setFrontViewController:controller animated:NO];
        [swvc revealToggleAnimated:YES];
    }
    if(indexPath.row==7)
    {
        UIStoryboard *storyboard = [UIStoryboard storyboardWithName:@"Main" bundle:nil];
        PathMenuViewController *controller = [storyboard instantiateViewControllerWithIdentifier:@"PathMenuViewController"];
//        [self.navigationController pushViewController:controller animated:YES];
        [swvc setFrontViewController:controller animated:NO];
        [swvc revealToggleAnimated:YES];
    }
    if(indexPath.row==3)
    {
        UIStoryboard *storyboard = [UIStoryboard storyboardWithName:@"Main" bundle:nil];
        SettingsViewController *controller = [storyboard instantiateViewControllerWithIdentifier:@"SettingsViewController"];
//        [self.navigationController pushViewController:controller animated:YES];
        [swvc setFrontViewController:controller animated:NO];
        [swvc revealToggleAnimated:YES];
//        [[self navigationController]setNavigationBarHidden:YES];
    }
        if(indexPath.row==9)
        {
            UIStoryboard *storyboard = [UIStoryboard storyboardWithName:@"Main" bundle:nil];
            CarouselViewController *controller = [storyboard instantiateViewControllerWithIdentifier:@"CarouselViewController"];
//            [self.navigationController pushViewController:controller animated:YES];
            [swvc setFrontViewController:controller animated:NO];
            [swvc revealToggleAnimated:YES];
    }
    if(indexPath.row==6)
    {
        UIStoryboard *storyboard = [UIStoryboard storyboardWithName:@"Main" bundle:nil];
       CKViewController *controller = [storyboard instantiateViewControllerWithIdentifier:@"calender"];
        //            [self.navigationController pushViewController:controller animated:YES];
        [swvc setFrontViewController:controller animated:NO];
        [swvc revealToggleAnimated:YES];
    }
    if(indexPath.row==10)
    {
        UIStoryboard *storyboard = [UIStoryboard storyboardWithName:@"Main" bundle:nil];
        EandCViewController *controller = [storyboard instantiateViewControllerWithIdentifier:@"EandCViewController"];
//        [self.navigationController pushViewController:controller animated:YES];
        [swvc setFrontViewController:controller animated:NO];
        [swvc revealToggleAnimated:YES];
    }
    if(indexPath.row==8)
    {
        UIStoryboard *storyboard = [UIStoryboard storyboardWithName:@"Main" bundle:nil];
        BoopsViewController *controller = [storyboard instantiateViewControllerWithIdentifier:@"BoopsViewController"];
        [swvc setFrontViewController:controller];
        [swvc revealToggleAnimated:YES];    }
    
    
}
/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
