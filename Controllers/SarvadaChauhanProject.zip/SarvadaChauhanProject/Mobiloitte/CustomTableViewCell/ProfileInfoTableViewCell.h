//
//  ProfileInfoTableViewCell.h
//  Mobiloitte
//
//  Created by Akash sharma on 16/03/17.
//  Copyright © 2017 Mobiloitte. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ProfileInfoTableViewCell : UITableViewCell
@property (weak, nonatomic) IBOutlet UIImageView *profileImage;
@property (weak, nonatomic) IBOutlet UILabel *userDob;
@property (weak, nonatomic) IBOutlet UILabel *userMob;

@end
