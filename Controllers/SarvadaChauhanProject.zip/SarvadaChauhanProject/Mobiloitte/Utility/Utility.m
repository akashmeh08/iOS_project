//
//  Utility.m
//  Mobiloitte
//
//  Created by Mobiloitte on 14/03/17.
//  Copyright © 2017 Mobiloitte. All rights reserved.
//

#import "Utility.h"

@implementation Utility

-(NSString*)isValidate:(NSString *)myEmail :(NSString *)password
{
    NSString *res = @"Success";
    if([myEmail isEqualToString:@""])
    {
        res = @"Please enter email id.";
    }
    else if(myEmail.length<6)
    {
        res=@"Please enter minimum 6 characters email id.";
    }
    else if(myEmail.length>50)
    {
        res=@"Please enter maximum 50 characters email id.";
    }
    else if(emailCheck(myEmail))
    {
        res=@"Please enter valid email id.";
    }
    else if([password isEqualToString:@""])
    {
        res=@"Please enter password.";
    }
    else if(password.length<8)
    {
        res=@"Please enter minimum 8 characters password.";
    }
    else if(password.length>25)
    {
        res=@"Please enter maximum 25 characters password.";
    }
    
    return res;
}
bool emailCheck(NSString *myEmail )
{
    NSString *emailRegex = @"[a-zA-Z0-9_.+-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,4}";
    NSPredicate *emailTest = [NSPredicate predicateWithFormat:@"SELF MATCHES %@", emailRegex];
    if ([emailTest evaluateWithObject:myEmail])
    {
       
        return false;
    }
    else
    {
        return true;
    }
   
}


  

@end
