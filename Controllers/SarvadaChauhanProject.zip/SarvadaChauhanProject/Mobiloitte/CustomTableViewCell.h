//
//  CustomTableViewCell.h
//  Mobiloitte
//
//  Copyright © 2017 Mobiloitte. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface CustomTableViewCell : UITableViewCell

@property (weak, nonatomic) IBOutlet UILabel *title_label;
@property (weak, nonatomic) IBOutlet UITextField *signup_textField;
@property (weak, nonatomic) IBOutlet UIButton *signup_textFieldButton;
@property (weak, nonatomic) IBOutlet UIImageView *downArrow_imageView;
@property (weak, nonatomic) IBOutlet UIButton *male_button;
@property (weak, nonatomic) IBOutlet UIButton *female_button;
@property (weak, nonatomic) IBOutlet UIButton *a_button;
@property (weak, nonatomic) IBOutlet UIButton *b_button;
@property (weak, nonatomic) IBOutlet UIButton *c_button;
@property (weak, nonatomic) IBOutlet UIButton *d_button;
@property (weak, nonatomic) IBOutlet UISegmentedControl *notification_segment;

@end
