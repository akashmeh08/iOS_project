//
//  NSObject+NSString.m
//  Mobiloitte
//
//  Copyright © 2017 Mobiloitte. All rights reserved.
//

#import "NSObject+NSString.h"


@implementation NSObject (NSString)
-(BOOL)isTextFieldBlank:(NSString *) textField
{
    if([textField isEqualToString:@""])
        return false;
    else
        return true;
    
}
-(BOOL)isValidEmailLength: (NSString *) emailId
{
    if(emailId.length < 8)
        return true;
    else
        return false;
}
-(BOOL)isValidEmailId: (NSString *) emailId
{
    NSString *emailRegex = @"[A-Z0-9a-z]+([._%+-]{1}[A-Z0-9a-z]+)*@[A-Z0-9a-z]+([.-]{1}[A-Z0-9a-z]+)*(\\.[A-Za-z]{2,4}){0,1}";
    //NSString *emailRegex = @"[a-zA-Z0-9_.+-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,4}";
    
    NSPredicate *emailTest = [NSPredicate predicateWithFormat:@"SELF MATCHES %@", emailRegex];
    if ([emailTest evaluateWithObject:emailId])
    {
        
        return true;
    }
    else
    {
        return false;
    }
    
}
-(BOOL)isvalidname:(NSString *)f_name
{
    NSString *emailRegex = @"[A-Za-z\b]*";
    NSPredicate *regex = [NSPredicate predicateWithFormat:@"SELF MATCHES %@", emailRegex];
    return [regex evaluateWithObject:f_name];
    
}
-(BOOL)isvalidlastname:(NSString *)l_name
{
    NSString *emailRegex = @"[A-Za-z\b]*";
    NSPredicate *regex = [NSPredicate predicateWithFormat:@"SELF MATCHES %@", emailRegex];
    return [regex evaluateWithObject:l_name];
    
}
-(BOOL)isValidMobileNumber:(NSString *) mobileNumber
{
    //    NSString *stringToBeTested = @"8123456789";
    
    NSString *mobileNumberPattern = @"[0-9]";
    NSPredicate *mobileNumberPred = [NSPredicate predicateWithFormat:@"SELF MATCHES %@", mobileNumberPattern];
    
    return [mobileNumberPred evaluateWithObject:mobileNumber];
}
-(BOOL)checkPasswordLength:(NSString *) password
{
    if(password.length < 4)
        return true;
    else
        return false;
    
}
-(BOOL)comparePassword:(NSString*) password :(NSString*) confirmPassword
{
    if(![password isEqualToString:confirmPassword])
    {
        return true;
    }
    else
    {
        return false;
    }
}
-(BOOL)checkSpecification:(int ) count
{
    if(count <= 2)
        return true;
    else
        return false;
    
}


/*-(BOOL)isTextFieldBlank:(NSString *) textField
{
    if([textField isEqualToString:@""])
        return false;
    else
        return true;
    
}
-(BOOL)isValidEmailLength: (NSString *) emailId
{
    if(emailId.length < 8)
        return true;
    else
        return false;
}
-(BOOL)isValidEmailId: (NSString *) emailId
{
    NSString *emailRegex = @"[a-zA-Z0-9_.+-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,4}";
    NSPredicate *emailTest = [NSPredicate predicateWithFormat:@"SELF MATCHES %@", emailRegex];
    if ([emailTest evaluateWithObject:emailId])
    {
        
        return true;
    }
    else
    {
        return false;
    }

}
-(BOOL)isValidMobileNumber:(NSString *) mobileNumber
{
//    NSString *stringToBeTested = @"8123456789";
    
    NSString *mobileNumberPattern = @"[0-9]";
    NSPredicate *mobileNumberPred = [NSPredicate predicateWithFormat:@"SELF MATCHES %@", mobileNumberPattern];
    
    return [mobileNumberPred evaluateWithObject:mobileNumber];
}
-(BOOL)checkPasswordLength:(NSString *) password
{
    if(password.length < 4)
        return true;
    else
        return false;
    
}
-(BOOL) isValidNumber:(NSString *) phone{
    
    NSString *mobileNumberPattern = @"[0-9]";
    NSPredicate *mobileNumberPred = [NSPredicate predicateWithFormat:@"SELF MATCHES %@", mobileNumberPattern];
    
    return [mobileNumberPred evaluateWithObject:phone];
}
-(BOOL)comparePassword:(NSString*) password :(NSString*) confirmPassword
{
    if(![password isEqualToString:confirmPassword])
    {
        return true;
    }
    else
    {
        return false;
    }
}
-(BOOL)checkSpecification:(int ) count
{
    if(count <= 2)
        return true;
    else
        return false;
    
}
*/


@end
