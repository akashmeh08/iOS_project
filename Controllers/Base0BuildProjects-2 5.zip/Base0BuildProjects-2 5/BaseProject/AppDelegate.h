//
//  AppDelegate.h
//  BaseProject
//

#import <UIKit/UIKit.h>
#import "Macro.h"

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@property (nonatomic, assign) BOOL       isReachable;

@end

