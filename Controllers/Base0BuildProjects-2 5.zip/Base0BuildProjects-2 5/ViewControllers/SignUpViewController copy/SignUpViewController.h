//
//  SignUpViewController.h
//  BaseProject
//
//  Created by Mobiloitte on 24/03/17.
//  Copyright © 2017 Mobiloitte. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface SignUpViewController : UIViewController
- (IBAction)onGenderBtnAction:(id)sender;
- (IBAction)onTermsCheckBtn:(id)sender;
- (IBAction)setprofilePicture:(id)sender;

- (IBAction)termsAndPolicyButton:(id)sender;

@end
