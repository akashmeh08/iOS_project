//
//  SendAccessCodeViewController.h
//  BaseProject
//
//  Created by Mobiloitte on 25/03/17.
//  Copyright © 2017 Mobiloitte. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface SendAccessCodeViewController : UIViewController

@end
