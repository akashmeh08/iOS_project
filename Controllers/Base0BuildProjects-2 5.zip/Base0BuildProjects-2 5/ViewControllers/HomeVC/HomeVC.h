//
//  HomeVC.h
//  BaseProject
//
//  Created by Mobiloitte TRG on 09/03/17.
//  Copyright © 2017 Mobiloitte. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "Macro.h"

@interface HomeVC : UIViewController

@end
