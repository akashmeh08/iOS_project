//
//  signupViewController.h
//  myFirstProject
//
//  Created by Sarvada Chauhan on 09/03/17.
//  Copyright © 2017 Sarvada Chauhan. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "NSObject+NSString.h"
#import <UIKit/UIKit.h>

@interface signupViewController :UIViewController

@end
