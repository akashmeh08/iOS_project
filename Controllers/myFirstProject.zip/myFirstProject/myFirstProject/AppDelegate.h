//
//  AppDelegate.h
//  myFirstProject
//
//  Created by Sarvada Chauhan on 06/03/17.
//  Copyright © 2017 Sarvada Chauhan. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

