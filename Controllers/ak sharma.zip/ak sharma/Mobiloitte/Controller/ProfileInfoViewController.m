//
//  ProfileInfoViewController.m
//  Mobiloitte
//
//  Created by Suraj on 16/03/17.
//  Copyright © 2017 Mobiloitte. All rights reserved.
//

#import "ProfileInfoViewController.h"
#import "MUserInfo.h"

@interface ProfileInfoViewController ()

@property (weak, nonatomic) IBOutlet UIImageView *profileInfo;
@property (weak, nonatomic) IBOutlet UILabel *userDob;
@property (weak, nonatomic) IBOutlet UILabel *userMob;
@property (weak, nonatomic) IBOutlet UITextField *textField;

@end

@implementation ProfileInfoViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    self.navigationItem.title = @"Profile";
    // Do any additional setup after loading the view.
    
  
     [self customInit];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}





- (void)viewWillAppear:(BOOL)animated
{
    [self.navigationController setNavigationBarHidden:NO];
}
- (void)viewWillDisappear:(BOOL)animated
{
    [self.navigationController setNavigationBarHidden:YES];
}
-(void)customInit
{
    
    
    self.profileInfo.clipsToBounds = YES;
    _profileInfo.layer.borderWidth=1;
    _profileInfo.layer.cornerRadius = 50;
    
    int  rowNumber = [_userInfo.rowIndex intValue];
    self.navigationItem.title = [_userInfo.nameArray objectAtIndex:rowNumber];
   
    _profileInfo.image=[UIImage imageNamed:[_userInfo.imageView1 objectAtIndex:rowNumber]];
    _userDob.text=[_userInfo.dobArray objectAtIndex:rowNumber];
    _userMob.text=[_userInfo.phoneNo objectAtIndex:rowNumber];
    
    
}
-(void)textFieldDidBeginEditing:(UITextField *)textField
{
    //  textField.autocapitalizationType = UITextAutocapitalizationTypeWords ;
    
    if(textField.frame.origin.y)
        [self animateTextField:textField up:YES];
    
}

- (void)textFieldDidEndEditing:(UITextField *)textField
{
    [self animateTextField:textField up:NO];
    
}
-(void)animateTextField:(UITextField*)textField up:(BOOL)up
{
    
    
    int movementDistance = -90; // tweak as needed
    
    const float movementDuration = 0.3f; // tweak as needed
    
    int movement = (up ? movementDistance : -movementDistance);
    
    [UIView beginAnimations: @"animateTextField" context: nil];
    [UIView setAnimationBeginsFromCurrentState: YES];
    [UIView setAnimationDuration: movementDuration];
    self.view.frame = CGRectOffset(self.view.frame, 0, movement);
    [UIView commitAnimations];
}
- (void)touchesBegan:(NSSet *)touches withEvent:(UIEvent *)event
{
    [_textField resignFirstResponder];
}
/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
