//
//  HomeViewController.m
//  Mobiloitte
//
//  Created by Akash sharma on 16/03/17.
//  Copyright © 2017 Mobiloitte. All rights reserved.
//

#import "HomeViewController.h"
#import "HomeTableViewCell.h"
#import "MUserInfo.h"
#import "ProfileInfoViewController.h"
#import "SegmentViewController.h"
#import "SWRevealViewController.h"
@interface HomeViewController ()<UITableViewDelegate,UITableViewDataSource>
{
    MUserInfo *userInfo;
}

- (IBAction)nextBtn:(id)sender;
@end

@implementation HomeViewController


- (void)viewDidLoad {
    [super viewDidLoad];
    [self.navigationController setNavigationBarHidden:YES];
    // Do any additional setup after loading the view.
   
    
    
    SWRevealViewController *revealViewController = self.revealViewController;
    if ( revealViewController )
    {
        [self.menuButton setTarget:self.revealViewController];
        [self.menuButton setAction: @selector( revealToggle: )];
        [self.view addGestureRecognizer:self.revealViewController.panGestureRecognizer];
    }

    [self customInit];
}


-(void)rightButtonClick
{
    UIStoryboard* storyboard = [UIStoryboard storyboardWithName:@"Main" bundle:nil];
    SegmentViewController *controller = [storyboard instantiateViewControllerWithIdentifier:@"SegmentViewController"];
   
    [self.navigationController pushViewController:controller animated:YES ];
}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}
//
//- (void)viewWillAppear:(BOOL)animated
//{
//    [self.navigationController setNavigationBarHidden:YES];
//}
//- (void)viewWillDisappear:(BOOL)animated
//{
//    [self.navigationController setNavigationBarHidden:NO];
//}

-(void)customInit
{
    
    userInfo = [[MUserInfo alloc]init];
    userInfo.nameArray=[[NSArray alloc]initWithObjects:@"Akash Sharma",@"Kunal Arora",@"Sunil Joshi",@"Suraj Joshi",@"Abhishek Tripathi",@"Rahul Mithani",@"GaganDeep",@"Raman Deep",@"Anjali Sharma",@"Priyanshi Gupta", nil];
    userInfo.dobArray =[[NSArray alloc]initWithObjects:@"01-Apr-1991",@"06-Dec-1991",@"01-Oct-1995",@"04-Nov-1991",@"01-Feb-1992",@"05-Jan-1995",
                        @"10-Jul-1992",@"12-Jan-1991",@"025-Nov-1991",@"30-Sep-1991",nil];
    userInfo.phoneNo =[[NSArray alloc]initWithObjects:@"9997449035",@"9897993355",@"9897556688",@"9897514513",@"9634111555",@"8764567783",@"8645467392",@"7845673654",@"9484764898",@"8545695528",nil];
    userInfo.imageView1 =[[NSArray alloc]initWithObjects:@"images9.png",@"images10.jpg",@"images2.jpg",@"images3.jpg",@"images4.jpg",@"images5.jpg",@"images6.jpg",@"images7.jpg",@"images8.png",@"images9.png",nil];
}
#pragma mark - Navigation


- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    return 10;
}



- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    HomeTableViewCell *cell=(HomeTableViewCell*)[tableView dequeueReusableCellWithIdentifier:@"HomeTableViewCell"];
    cell.accessoryType = UITableViewCellAccessoryDisclosureIndicator;
    //cell.userInteractionEnabled = NO;
    cell.titleLabel.text = [userInfo.nameArray objectAtIndex:indexPath.row];
    cell.dob.text = [userInfo.dobArray objectAtIndex:indexPath.row];
    cell.mobileNo.text = [userInfo.phoneNo objectAtIndex:indexPath.row];
    cell.imageview.layer.cornerRadius = 34;
    cell.imageview.layer.borderWidth = 1;
    cell.self.imageview.clipsToBounds = YES;
    cell.selectionStyle=UITableViewCellSelectionStyleNone;
    
    
    cell.imageview.image = [UIImage imageNamed:[userInfo.imageView1 objectAtIndex:indexPath.row]];
    return cell;
}


- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    
    userInfo.rowIndex=[NSString stringWithFormat:@"%li", indexPath.row];
    UIStoryboard* storyboard = [UIStoryboard storyboardWithName:@"Main" bundle:nil];
    ProfileInfoViewController *controller = [storyboard instantiateViewControllerWithIdentifier:@"ProfileInfoViewController"];
    controller.userInfo=[MUserInfo new];
    controller.userInfo=userInfo;
    [self.navigationController pushViewController:controller animated:YES ];
    
    
}

- (IBAction)nextBtn:(id)sender {
    UIStoryboard* storyboard = [UIStoryboard storyboardWithName:@"Main" bundle:nil];
    SegmentViewController *controller = [storyboard instantiateViewControllerWithIdentifier:@"SegmentViewController"];
    
    [self.navigationController pushViewController:controller animated:YES ];
}
@end
