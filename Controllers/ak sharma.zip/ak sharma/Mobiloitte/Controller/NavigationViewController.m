//
//  NavigationViewController.m
//  Mobiloitte
//
//  Created by Akash sharma on 18/03/17.
//  Copyright © 2017 Mobiloitte. All rights reserved.
//

#import "NavigationViewController.h"
#import "TPViewController.h"
#import "EandCViewController.h"
#import "PathMenuViewController.h"
#import "SettingsViewController.h"
#import "DashBoardViewController.h"
#import "HomeViewController.h"
#import "ChatViewController.h"
#import "CKViewController.h"
#import "CarouselViewController.h"
#import "BoopsViewController.h"
#import "LoginViewController.h"

@interface NavigationViewController ()<UITableViewDelegate,UITableViewDataSource>
@property (weak, nonatomic) IBOutlet UITableView *tableView1;

@end

@implementation NavigationViewController
{
    NSArray *menu;
}
- (void)viewDidLoad {
    [super viewDidLoad];
    
    menu= @[@"Home",@"Dashboard",@"Chat",@"Settings",@"Graphs",@"Rate",@"Calendar",@"Path Menu",@"Boops",@"Carousel",@"Expandable List",@"Logout"];
    self.tableView1.scrollEnabled = YES;
    self.tableView1.tableFooterView=[[UIView alloc]initWithFrame:CGRectZero];
    // Do any additional setup after loading the view.
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return [menu count];
}

// Row display. Implementers should *always* try to reuse cells by setting each cell's reuseIdentifier and querying for available reusable cells with dequeueReusableCellWithIdentifier:
// Cell gets various attributes set automatically based on table (separators) and data source (accessory views, editing controls)

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"Cell"];
    
    if (cell==nil) {
        cell = [[UITableViewCell alloc]initWithStyle:UITableViewCellStyleSubtitle reuseIdentifier:@"Cell"];
        
    }
    cell.textLabel.text = [menu objectAtIndex:indexPath.row];
    cell.selectionStyle=UITableViewCellSelectionStyleNone;
    return cell;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    SWRevealViewController *srvc=self.revealViewController;
    
    if(indexPath.row==0)
    {
        UIStoryboard *storyboard = [UIStoryboard storyboardWithName:@"Main" bundle:nil];
        HomeViewController *controller = [storyboard instantiateViewControllerWithIdentifier:@"HomeViewController"];
        [self.navigationController pushViewController:controller animated:YES];
    }
    
    if(indexPath.row==2)
    {
        UIStoryboard *storyboard = [UIStoryboard storyboardWithName:@"Main" bundle:nil];
        ChatViewController *controller = [storyboard instantiateViewControllerWithIdentifier:@"Chat"];
        [srvc setFrontViewController:controller];
        [srvc revealToggleAnimated:YES];
    }
    if(indexPath.row==1)
    {
        UIStoryboard *storyboard = [UIStoryboard storyboardWithName:@"Main" bundle:nil];
        DashBoardViewController *controller = [storyboard instantiateViewControllerWithIdentifier:@"DashBoardViewController"];

        [srvc setFrontViewController:controller];
        [srvc revealToggleAnimated:YES];
    }
    if(indexPath.row==5)
    {
        UIStoryboard *storyboard = [UIStoryboard storyboardWithName:@"Main" bundle:nil];
        TPViewController *controller = [storyboard instantiateViewControllerWithIdentifier:@"TPViewController"];
        [srvc setFrontViewController:controller];
        [srvc revealToggleAnimated:YES];
    }
    if(indexPath.row==7)
    {
        UIStoryboard *storyboard = [UIStoryboard storyboardWithName:@"Main" bundle:nil];
        PathMenuViewController *controller = [storyboard instantiateViewControllerWithIdentifier:@"PathMenuViewController"];
        [srvc setFrontViewController:controller];
        [srvc revealToggleAnimated:YES];
    }
    
    
    if(indexPath.row==3)
    {
        UIStoryboard *storyboard = [UIStoryboard storyboardWithName:@"Main" bundle:nil];
        SettingsViewController *controller = [storyboard instantiateViewControllerWithIdentifier:@"SettingsViewController"];
        [srvc setFrontViewController:controller];
        [srvc revealToggleAnimated:YES];
    }
    if(indexPath.row==9)
    {
        UIStoryboard *storyboard = [UIStoryboard storyboardWithName:@"Main" bundle:nil];
        CarouselViewController *controller = [storyboard instantiateViewControllerWithIdentifier:@"CarouselViewController"];
        [srvc setFrontViewController:controller];
        [srvc revealToggleAnimated:YES];    }
    
    if(indexPath.row==6)
    {
        UIStoryboard *storyboard = [UIStoryboard storyboardWithName:@"Main" bundle:nil];
        CKViewController *controller = [storyboard instantiateViewControllerWithIdentifier:@"CKViewController"];
        [srvc setFrontViewController:controller];
        [srvc revealToggleAnimated:YES];    }
    
    if(indexPath.row==8)
    {
        UIStoryboard *storyboard = [UIStoryboard storyboardWithName:@"Main" bundle:nil];
        BoopsViewController *controller = [storyboard instantiateViewControllerWithIdentifier:@"BoopsViewController"];
        [srvc setFrontViewController:controller];
        [srvc revealToggleAnimated:YES];    }
    
    if(indexPath.row==10)
    {
        UIStoryboard *storyboard = [UIStoryboard storyboardWithName:@"Main" bundle:nil];
        EandCViewController *controller = [storyboard instantiateViewControllerWithIdentifier:@"EandCViewController"];
        [srvc setFrontViewController:controller];
        [srvc revealToggleAnimated:YES];
    }
    
    if(indexPath.row==11)
        
    {
        UIAlertController * alert=[UIAlertController
                                   
                                   alertControllerWithTitle:@"Alert" message:@"Are yor sure you want to logout."preferredStyle:UIAlertControllerStyleAlert];
        
        UIAlertAction* yesButton = [UIAlertAction
                                    actionWithTitle:@"Logout"
                                    style:UIAlertActionStyleDefault
                                    handler:^(UIAlertAction * action)
                                    {
                                        UIStoryboard* storyboard = [UIStoryboard storyboardWithName:@"Main" bundle:nil];
                                        LoginViewController * controller = [storyboard instantiateViewControllerWithIdentifier:@"LoginViewController"];
                                        
                                        [self.navigationController pushViewController:controller animated:YES ];
                                        
                                        
                                    }];
        UIAlertAction* noButton = [UIAlertAction
                                   actionWithTitle:@"Cancel"
                                   style:UIAlertActionStyleDefault
                                   handler:^(UIAlertAction * action)
                                   {
                                       //What we write here????????**
                                       
                                   }];
        
        [alert addAction:yesButton];
        [alert addAction:noButton];
        
        [self presentViewController:alert animated:YES completion:nil];
        
        
    }
    
    
}
//- (void)alertView:(UIAlertView *)alertView clickedButtonAtIndex:(NSInteger)buttonIndex{
//    if (buttonIndex == 0){
//        //delete it
//    }
//}

@end
