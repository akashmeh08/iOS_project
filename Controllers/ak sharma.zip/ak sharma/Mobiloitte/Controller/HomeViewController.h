//
//  HomeViewController.h
//  Mobiloitte
//
//  Created by Akash sharma on 16/03/17.
//  Copyright © 2017 Mobiloitte. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface HomeViewController : UIViewController
@property (weak, nonatomic) IBOutlet UIBarButtonItem *menuButton;

@end
