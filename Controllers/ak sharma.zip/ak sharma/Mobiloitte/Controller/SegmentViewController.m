//
//  SegmentViewController.m
//  Mobiloitte
//
//  Created by Akash sharma on 17/03/17.
//  Copyright © 2017 Mobiloitte. All rights reserved.
//

#import "SegmentViewController.h"

@interface SegmentViewController ()<UITableViewDelegate,UITableViewDataSource>
{
    NSArray *listArray;
}

@end

@implementation SegmentViewController
@synthesize segmentBtn;
@synthesize mapView = _mapView;


- (void)viewDidLoad {
    [super viewDidLoad];
    self.navigationItem.title = @"List & Map";
    // Do any additional setup after loading the view.

    self.navigationController.navigationBar.topItem.title = @"Back";
    self.navigationItem.title = @"List & Map";
    
    [segmentBtn addTarget:self action:@selector(segmentedControlChangedValue:) forControlEvents:UIControlEventValueChanged];
    listArray = [[NSArray alloc]initWithObjects:@"Kamesh Mishra",@"Sunny Singh",@"Akansha mishra",@"Samiksha",@"Mehak Mittal", nil];}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (void)viewWillAppear:(BOOL)animated
{
    [self.navigationController setNavigationBarHidden:NO];
}
- (void)viewWillDisappear:(BOOL)animated
{
    [self.navigationController setNavigationBarHidden:YES];
}


-(void)segmentedControlChangedValue:forControlEvents
{
    NSLog(@"%ld", (long)self.segmentBtn.selectedSegmentIndex);
    if(self.segmentBtn.selectedSegmentIndex == 1)
    {
        _listTableView.hidden=YES;
        _mapView.hidden=NO;
    }
    else
    {
        _listTableView.hidden=false;
       _mapView.hidden=true;
    }
}



- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    return [listArray count];
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    
    UITableViewCell *cell=(UITableViewCell *)[tableView dequeueReusableCellWithIdentifier:@"cell"];
    if (cell == nil) {
        cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:@"cell"];
    }
    
    cell.textLabel.text = [listArray objectAtIndex:indexPath.row];
    return cell;
    
}

@end
