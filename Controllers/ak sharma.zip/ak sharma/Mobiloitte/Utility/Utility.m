//
//  Utility.m
//  Mobiloitte
//
//  Created by Mobiloitte on 14/03/17.
//  Copyright © 2017 Mobiloitte. All rights reserved.
//

#import "Utility.h"
#import "Macro.h"

@implementation Utility

-(NSString*)isValidate:(NSString *)myEmail :(NSString *)password
{
    NSString *res = @"Success";
    if([myEmail isEqualToString:@""])
    {
        res =  KAlert_Empty_EmailID;
    }
    else if(myEmail.length<6)
    {
        res= KAlert_MinLength_EmailID;
    }
    
    else if(emailCheck(myEmail))
    {
        res= KAlert_Invalid_EmailID ;
    }
    else if([password isEqualToString:@""])
    {
        res=KAlert_Empty_Password;
    }
    else if(password.length<8)
    {
        res= KAlert_MinLength_Password;
    }
   
    return res;
}
bool emailCheck(NSString *myEmail )
{
    NSString *emailRegex = @"[A-Z0-9a-z._%+-]+@[A-Z0-9a-z-]+\\.[A-Za-z]{2,4}";
    NSPredicate *emailTest = [NSPredicate predicateWithFormat:@"SELF MATCHES %@", emailRegex];
    if ([emailTest evaluateWithObject:myEmail])
    {
       
        return false;
    }
    else
    {
        return true;
    }
   
}


  

@end
