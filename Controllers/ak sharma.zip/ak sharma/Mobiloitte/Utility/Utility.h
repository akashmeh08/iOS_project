//
//  Utility.h
//  Mobiloitte
//
//  Created by Mobiloitte on 14/03/17.
//  Copyright © 2017 Mobiloitte. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface Utility : NSObject

-(NSString*)isValidate:(NSString*)email :(NSString*)password;


@end
