//
//  HomeTableViewCell.m
//  Mobiloitte
//
//  Created by Akash sharma on 16/03/17.
//  Copyright © 2017 Mobiloitte. All rights reserved.
//

#import "HomeTableViewCell.h"

@implementation HomeTableViewCell

- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
