//
//  CarouselViewController.h
//  Mobiloitte
//
//  Created by Suraj_Joshi on 20/03/17.
//  Copyright © 2017 Mobiloitte. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface CarouselViewController : UIViewController
{
    NSMutableArray *images;
}

@end
