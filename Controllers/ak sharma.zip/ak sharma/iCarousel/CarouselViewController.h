//
//  CarouselViewController.h
//  Mobiloitte
//
//  Created by Akash Mehrotra on 20/03/17.
//  Copyright © 2017 Mobiloitte. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "iCarousel.h"

@interface CarouselViewController : UIViewController
{
    NSMutableArray *images;

}
@property (weak, nonatomic) IBOutlet UIBarButtonItem *barButton;
@property (weak, nonatomic) IBOutlet iCarousel *carosel;
@end
