//
//  MailComposerViewController.m
//  Mobiloitte
//
//  Created by Mobiloitte on 21/03/17.
//  Copyright © 2017 Mobiloitte. All rights reserved.
//

#import "MailComposerViewController.h"
#import <MessageUI/MessageUI.h>
@interface MailComposerViewController ()

@end

@implementation MailComposerViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    [self.navigationController setNavigationBarHidden:NO];
     self.navigationItem.title = @"Contact Us";
    
    UIImage* send = [UIImage imageNamed:@"MessageSent-128"];
    CGRect frameimg = CGRectMake(0, 0, 60, 55);
    
    UIButton *someButton = [[UIButton alloc] initWithFrame:frameimg];
    [someButton setBackgroundImage:send  forState:UIControlStateNormal ];
    [someButton addTarget:self action:@selector(sendMail)
         forControlEvents:UIControlEventTouchUpInside];
    [someButton setShowsTouchWhenHighlighted:YES];
       UIBarButtonItem *mailbutton =[[UIBarButtonItem alloc] initWithCustomView:someButton];
    self.navigationItem.rightBarButtonItem=mailbutton;
    UITapGestureRecognizer *tap = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(dismissKeyboard)];
    
    [self.view addGestureRecognizer:tap];

    
}
-(void)dismissKeyboard
{
    [_fromMailComposerTextField resignFirstResponder];
    [_subjecMailComposerTextField resignFirstResponder];
    [_toMailComposerTextField resignFirstResponder];
    [_comaposeMailTextView resignFirstResponder];

    
}
-(void) sendMail
{
    
    
    
        NSString *emailTitle = (NSString*)_subjecMailComposerTextField.text;
        // Email Content
        NSString *messageBody = (NSString*)_comaposeMailTextView.text ;
        // To address
        NSArray *toRecipents = [NSArray arrayWithObject:@"support@appcoda.com"];
        Class mailClass = (NSClassFromString(@"MFMailComposeViewController"));
        if (mailClass != nil) {
            MFMailComposeViewController * mailView = [[MFMailComposeViewController alloc]   init];
            mailView.mailComposeDelegate = self;
    
            //Set the subject
            [mailView setSubject:emailTitle];
    
            //Set the mail body
            [mailView setMessageBody:messageBody isHTML:YES];
    
    
            //Display Email Composer
            if([mailClass canSendMail]) {
            [self presentViewController:mailView animated:YES completion:NULL];
        }
    
    
    
    // Present mail view controller on screen
    
}
//- (void) mailComposeController:(MFMailComposeViewController *)controller didFinishWithResult:(MFMailComposeResult)result error:(NSError *)error
//{
//    switch (result)
//    {
//            case 0:
//            NSLog(@"failed");
//            break;
//        case 1:
//            NSLog(@"1");
//            break;
//        case 2:
//            NSLog(@"2");
//            break;
//               default:
//            break;
//    }
//    
    // Close the Mail Interface
    [self dismissViewControllerAnimated:YES completion:NULL];
}

//Class mailClass = (NSClassFromString(@"MFMailComposeViewController"));
//if (mailClass != nil) {
//    MFMailComposeViewController * mailView = [[MFMailComposeViewController alloc] init];
//    mailView.mailComposeDelegate = self;
//    
//    //Set the subject
//    [mailView setSubject:emailSubject];
//    
//    //Set the mail body
//    [mailView setMessageBody:emailBody isHTML:YES];
//    
//    
//    //Display Email Composer
//    if([mailClass canSendMail]) {
//        [self.navControl presentModalViewController:mailView animated:YES];
//    }
//}
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}
-(void) viewWillDisappear:(BOOL)animated {
    [self.navigationController setNavigationBarHidden:YES];
       [super viewWillDisappear:animated];
    }
/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/
-(BOOL)textFieldShouldReturn:(UITextField *)textField
{
    if(textField.returnKeyType==UIReturnKeyNext)
    {
        UITextField *tf=(UITextField *)[self.view viewWithTag:textField.tag+1];
        [tf becomeFirstResponder];
    }
    else
    {
        [self.view endEditing:YES];
    }
    return YES;
}
- (void)textViewDidEndEditing:(UITextView*)textView

{
    [self animateTextField:textView up:NO];
    
}
-(void)animateTextField:(UITextView*) textView up:(BOOL)up
{
    
    
    int movementDistance = -40; // tweak as needed
    
    const float movementDuration = 0.3f; // tweak as needed
    
    int movement = (up ? movementDistance : -movementDistance);
    
    [UIView beginAnimations: @"animateTextField" context: nil];
    [UIView setAnimationBeginsFromCurrentState: YES];
    [UIView setAnimationDuration: movementDuration];
    self.view.frame = CGRectOffset(self.view.frame, 0, movement);
    [UIView commitAnimations];
}


- (BOOL)textViewShouldBeginEditing:(UITextView *)textView{
    NSLog(@"textViewShouldBeginEditing:");
    if(textView.frame.origin.y)
        [self animateTextField:textView up:YES];
    return YES;
}

- (void)textViewDidBeginEditing:(UITextView *)textView {
    NSLog(@"textViewDidBeginEditing:");
    //    textView.backgroundColor = [UIColor greenColor];
    textView.textColor = [UIColor blackColor];
    textView.text = @"";
}

@end
