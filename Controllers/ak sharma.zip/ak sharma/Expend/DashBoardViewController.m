//
//  DashBoardViewController.m
//  Mobiloitte
//
//  Created by Mobiloitte on 18/03/17.
//  Copyright © 2017 Mobiloitte. All rights reserved.
//

#import "DashBoardViewController.h"
#import "DashBoardCollectionViewCell.h"
#import "SWRevealViewController.h"
@interface DashBoardViewController ()<UICollectionViewDelegate,UICollectionViewDataSource,UIGestureRecognizerDelegate>
@property (weak, nonatomic) IBOutlet UIImageView *imageView1;
- (IBAction)cancel:(id)sender;

@end
CGFloat lastScale;
@implementation DashBoardViewController

{
    NSArray *dashBoardImageList;
}
- (void)viewDidLoad {
    [super viewDidLoad];
    _dashView.backgroundColor=[UIColor whiteColor];
   [self.navigationController setNavigationBarHidden:YES];
    // Do any additional setup after loading the view.
    
    SWRevealViewController *revealViewController =self.revealViewController; //[[SWRevealViewController alloc]init];
    if ( revealViewController )
    {
     
        [self.dashBoardMenuButton setTarget:self.revealViewController];
        [self.dashBoardMenuButton setAction: @selector( revealToggle: )];
        [self.view addGestureRecognizer:self.revealViewController.panGestureRecognizer];
    }
    
    
    self.view.backgroundColor = [UIColor whiteColor];
    
    UIPinchGestureRecognizer *pgr = [[UIPinchGestureRecognizer alloc]
                                     initWithTarget:self action:@selector(handlePinchGesture:)];
    pgr.delegate = self;
    [_imageView1 addGestureRecognizer:pgr];
    
    dashBoardImageList = [[NSArray alloc]initWithObjects:@"Unknown-7",@"images13",@"images12",@"images14",@"images15",@"images16",@"images17",@"Unknown-7",@"img1",@"rain-colorful",@"Unknown-7",@"images13",@"img2",@"img3",@"img4",@"images16",@"images17",@"Unknown-7",@"img1",@"rain-colorful",nil];
}


- (void)viewWillAppear:(BOOL)animated
{
    [self.navigationController setNavigationBarHidden:YES];
    _imageView1.hidden=YES;
}
- (void)viewWillDisappear:(BOOL)animated
{
    [self.navigationController setNavigationBarHidden:YES];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


- (NSInteger)collectionView:(UICollectionView *)collectionView numberOfItemsInSection:(NSInteger)section{
    return [dashBoardImageList count];
}

// The cell that is returned must be retrieved from a call to -dequeueReusableCellWithReuseIdentifier:forIndexPath:
- (__kindof UICollectionViewCell *)collectionView:(UICollectionView *)collectionView cellForItemAtIndexPath:(NSIndexPath *)indexPath{
    
    UICollectionViewCell *cell = (UICollectionViewCell*) [collectionView dequeueReusableCellWithReuseIdentifier:@"Cell" forIndexPath:indexPath];
    UIImageView *recipeImageView = (UIImageView *)[cell viewWithTag:100];
    recipeImageView.image = [UIImage imageNamed:[dashBoardImageList objectAtIndex:indexPath.row]];
    cell.backgroundView = [[UIImageView alloc] initWithImage:[UIImage imageNamed:@"photo-frame.png"]];
    [self.view addSubview:recipeImageView];
    cell.backgroundColor=[UIColor colorWithPatternImage:[UIImage imageNamed:[dashBoardImageList objectAtIndex:indexPath.row]]];
    
    return cell;
    
 }

- (void)collectionView:(UICollectionView *)collectionView didSelectItemAtIndexPath:(NSIndexPath *)indexPath
{
    UIImage *img = [UIImage imageNamed:[dashBoardImageList objectAtIndex:indexPath.row]];
    _imageView1.hidden=NO;
    _dashView.hidden=YES;
    self.imageView1.image = img;
   
}

#pragma marks pinchgesture
- (void)handlePinchGesture:(UIPinchGestureRecognizer *)gestureRecognizer {
    
    if([gestureRecognizer state] == UIGestureRecognizerStateBegan) {
        // Reset the last scale, necessary if there are multiple objects with different scales.
        lastScale = [gestureRecognizer scale];
    }
    
    if ([gestureRecognizer state] == UIGestureRecognizerStateBegan ||
        [gestureRecognizer state] == UIGestureRecognizerStateChanged) {
        
        CGFloat currentScale = [[[gestureRecognizer view].layer valueForKeyPath:@"transform.scale"] floatValue];
        
        // Constants to adjust the max/min values of zoom.
        const CGFloat kMaxScale = 2.0;
        const CGFloat kMinScale = 1.0;
        
        CGFloat newScale = 1 -  (lastScale - [gestureRecognizer scale]); // new scale is in the range (0-1)
        newScale = MIN(newScale, kMaxScale / currentScale);
        newScale = MAX(newScale, kMinScale / currentScale);
        CGAffineTransform transform = CGAffineTransformScale([[gestureRecognizer view] transform], newScale, newScale);
        [gestureRecognizer view].transform = transform;
        
        lastScale = [gestureRecognizer scale];  // Store the previous. scale factor for the next pinch gesture call
    }
}


- (IBAction)cancel:(id)sender {
    _imageView1.hidden=YES;
    _dashView.hidden=NO;
    
    
}
@end
