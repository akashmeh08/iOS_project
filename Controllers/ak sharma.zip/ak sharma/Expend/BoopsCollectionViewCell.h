//
//  BoopsCollectionViewCell.h
//  Mobiloitte
//
//  Created by Mobiloitte on 20/03/17.
//  Copyright © 2017 Mobiloitte. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface BoopsCollectionViewCell : UICollectionViewCell
@property (strong, nonatomic) IBOutlet UIImageView *boopsImageView;

@end
