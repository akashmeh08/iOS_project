//
//  EandCViewController.h
//  EandC
//
//  Created by Mobiloitte on 18/03/17.
//  Copyright © 2017 Mobiloitte. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface EandCViewController : UIViewController
{
    NSMutableArray *visibleRows;
    NSMutableArray *cellInfo;
    NSArray *cell0SubMenuItemsArray;
    NSArray *cell1SubMenuItemsArray;
    BOOL isSection0Cell0Expanded;
    

}
//@property (weak, nonatomic) IBOutlet UITableView *tableView;

@property (weak, nonatomic) IBOutlet UITableView *tableView;
@property (weak, nonatomic) IBOutlet UIBarButtonItem *barButton;

@end
