//
//  DashBoardViewController.h
//  Mobiloitte
//
//  Created by Mobiloitte on 18/03/17.
//  Copyright © 2017 Mobiloitte. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "SWRevealViewController.h"
@interface DashBoardViewController : UIViewController
@property (strong, nonatomic) IBOutlet UIImageView *dashBoardImageView;
@property (strong, nonatomic) IBOutlet UIBarButtonItem *dashBoardMenuButton;
@property (weak, nonatomic) IBOutlet UICollectionView *dashView;


@end
