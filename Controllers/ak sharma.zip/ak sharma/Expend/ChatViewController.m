//
//  ChatViewController.m
//  NewScreensTest
//

//
//

#import "ChatViewController.h"

#import "ChatTableViewCell.h"
#import "SWRevealViewController.h"

@interface ChatViewController ()<UITableViewDelegate, UITableViewDataSource, UITextFieldDelegate>
{
    NSArray *receivedMsgs;
    NSUInteger count;
    NSString *sentMsg;
}
@property (weak, nonatomic) IBOutlet UITableView *chatTableView;
@property (weak, nonatomic) IBOutlet UIButton *sendButton;
@property (weak, nonatomic) IBOutlet UITextField *typingField;
@property (strong, nonatomic) IBOutlet UIBarButtonItem *dashBoardMenuButton;

@end

@implementation ChatViewController

- (void)viewDidLoad {
    [super viewDidLoad];
     
    SWRevealViewController *revealViewController =self.revealViewController; //[[SWRevealViewController alloc]init];
    if ( revealViewController )
    {
        
        [self.dashBoardMenuButton setTarget:self.revealViewController];
        [self.dashBoardMenuButton setAction: @selector( revealToggle: )];
        [self.view addGestureRecognizer:self.revealViewController.panGestureRecognizer];
        
        UITapGestureRecognizer *tap = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(dismissKeyboard)];
        
        [self.view addGestureRecognizer:tap];
    }

    count = 0;
    receivedMsgs = [[NSArray alloc]initWithObjects:@"Hello", @"Hi", @"I am XCode", @"May I Know who you actually are?", @"Lets Be Friends", @"Nice To Meet You", nil];
    // Do any additional setup after loading the view.
}

-(void)dismissKeyboard
{
    [_typingField resignFirstResponder];
}


- (void)viewWillAppear:(BOOL)animated
{
    [self.navigationController setNavigationBarHidden:YES];
}
- (void)viewWillDisappear:(BOOL)animated
{
    [self.navigationController setNavigationBarHidden:YES];
    
}




-(void)textFieldDidBeginEditing:(UITextField *)textField
{
    //  textField.autocapitalizationType = UITextAutocapitalizationTypeWords ;
    
    if(textField.frame.origin.y)
        [self animateTextField:textField up:YES];
    
}




- (void)textFieldDidEndEditing:(UITextField *)textField
{
    [self animateTextField:textField up:NO];
    
}



-(void)animateTextField:(UITextField*)textField up:(BOOL)up
{
    
    
    int movementDistance = -265; // tweak as needed
    
    const float movementDuration = 0.3f; // tweak as needed
    
    int movement = (up ? movementDistance : -movementDistance);
    
    [UIView beginAnimations: @"animateTextField" context: nil];
    [UIView setAnimationBeginsFromCurrentState: YES];
    [UIView setAnimationDuration: movementDuration];
    self.view.frame = CGRectOffset(self.view.frame, 0, movement);
    [UIView commitAnimations];
}









- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}
-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return 6;
}
-(CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    return 80;
}



- (IBAction)msgSent:(id)sender {
    sentMsg = _typingField.text;
    count = count + 1;
    _typingField.text=@"";
    [_chatTableView reloadData];
}



-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    ChatTableViewCell *cell1 = (ChatTableViewCell *)[tableView dequeueReusableCellWithIdentifier:@"cell1"];
    ChatTableViewCell *cell2 = (ChatTableViewCell *)[tableView dequeueReusableCellWithIdentifier:@"cell2"];
    
    switch (indexPath.row) {
        case 0:
        {
            cell2.senderImage.layer.cornerRadius = 34;
            cell2.senderImage.layer.borderWidth = 1;
            cell2.senderImage.clipsToBounds = YES;
            cell2.sentMessage.text = @"hey";
            return cell2;
            break;
        }
        case 1:
            {
            
            cell1.recievedMessage.text = [receivedMsgs objectAtIndex:0];
                cell1.receiverImage.layer.cornerRadius = 34;
                cell1.receiverImage.layer.borderWidth = 1;
                cell1.receiverImage.clipsToBounds = YES;
                return cell1;
            break;
            }
        case 2:
        {
            cell2.senderImage.layer.cornerRadius = 34;
            cell2.senderImage.layer.borderWidth = 1;
            cell2.senderImage.clipsToBounds = YES;
            cell2.sentMessage.text = @"hey";
            return cell2;
            break;
        }
        case 3:
        {
            
            cell1.recievedMessage.text = [receivedMsgs objectAtIndex:1];
            cell1.receiverImage.layer.cornerRadius = 34;
            cell1.receiverImage.layer.borderWidth = 1;
            cell1.receiverImage.clipsToBounds = YES;
            return cell1;
            break;
        }
        case 4:
        {
            cell2.senderImage.layer.cornerRadius = 34;
            cell2.senderImage.layer.borderWidth = 1;
            cell2.senderImage.clipsToBounds = YES;
            cell2.sentMessage.text = @"hey";
            return cell2;
            break;
        }
        case 5:
        {
            
            cell1.recievedMessage.text = [receivedMsgs objectAtIndex:2];
            cell1.receiverImage.layer.cornerRadius = 34;
            cell1.receiverImage.layer.borderWidth = 1;
            cell1.receiverImage.clipsToBounds = YES;
            return cell1;
            break;
        }
        default:
        {
            NSLog(@"hello");
            return cell2;
            break;
        }
            return cell2;
    }
}

@end
