//
//  SettingsViewController.m
//  Setting
//

//

#import "SettingsViewController.h"
//#import "CustomTableViewCell.h"
#import "SWRevealViewController.h"
#import "SettingCell.h"
#import "TermPrivacyAboutViewController.h"
#import "ChangePasswordViewController.h"
#import "MailComposerViewController.h"

@interface SettingsViewController ()<UITableViewDataSource, UITableViewDelegate>
@property (strong, nonatomic) IBOutlet UIBarButtonItem *sidebarButton;
@property (weak, nonatomic) IBOutlet UINavigationBar *navTitle;
@property (weak, nonatomic) IBOutlet UITableView *tableView2;


@end

@implementation SettingsViewController

- (void)viewDidLoad {
    [super viewDidLoad];

    SWRevealViewController *revealViewController = self.revealViewController;
    if ( revealViewController )
    {
        [self.sidebarButton setTarget:self.revealViewController];
        [self.sidebarButton setAction: @selector( revealToggle: )];
        [self.view addGestureRecognizer:self.revealViewController.panGestureRecognizer];
    }
    self.tableView2.scrollEnabled = YES;
    self.tableView2.tableFooterView=[[UIView alloc]initWithFrame:CGRectZero];

}


- (void)viewWillAppear:(BOOL)animated
{
    [self.navigationController setNavigationBarHidden:YES];
}
- (void)viewWillDisappear:(BOOL)animated
{
    [self.navigationController setNavigationBarHidden:YES];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    if(section == 0)
        return 1;
    else
        return 5;
}

-(CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    return 50;
}

-(NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    return 2;
}
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    SettingCell *cell = (SettingCell *)[tableView dequeueReusableCellWithIdentifier:@"settingsItem"];
    SettingCell *cell1 = (SettingCell *)[tableView dequeueReusableCellWithIdentifier:@"notifications"];
    if(cell == nil)
    {
        cell = [[SettingCell alloc]initWithStyle:UITableViewCellStyleDefault reuseIdentifier:@"settingsItem"];
    }
    if(cell1 == nil)
    {
        cell1 = [[SettingCell alloc]initWithStyle:UITableViewCellStyleDefault reuseIdentifier:@"notifications"];
    }
    if(indexPath.section == 0)
    {
        return cell1;
    }
    else
    {
        switch(indexPath.row)
        {
            case 0:
                cell.labelItemName.text = @"Terms & Conditions";
                
                break;
            case 1:
                cell.labelItemName.text = @"About Us";
                break;
            case 2:
                cell.labelItemName.text = @"Contact Us";
                break;
            case 3:
                cell.labelItemName.text = @"Change Password";
                break;
            case 4:
               cell.labelItemName.text = @"Privacy Policy";
                break;
    }
        cell.selectionStyle=UITableViewCellSelectionStyleNone;
        cell1.selectionStyle=UITableViewCellSelectionStyleNone;
    return cell;
    }
}
-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
if(indexPath.row == 1)
 {
    UIStoryboard *str = [UIStoryboard storyboardWithName:@"Main" bundle:nil];
    TermPrivacyAboutViewController *contr = [str instantiateViewControllerWithIdentifier:@"TermPrivacyAboutViewController"];
    [self.navigationController pushViewController:contr animated:YES];
    contr.result=@"About Us";
 }
            if(indexPath.section == 1 && indexPath.row==0)
        {
            UIStoryboard *str = [UIStoryboard storyboardWithName:@"Main" bundle:nil];
            TermPrivacyAboutViewController *contr = [str instantiateViewControllerWithIdentifier:@"TermPrivacyAboutViewController"];
            [self.navigationController pushViewController:contr animated:YES];
            self.navigationController.navigationBar.topItem.title=@"Terms & Conditions";
            
            contr.result=@"Terms & Conditions";
        }
    if(indexPath.row == 2)
    {
        UIStoryboard *str = [UIStoryboard storyboardWithName:@"Main" bundle:nil];
        MailComposerViewController *contr = [str instantiateViewControllerWithIdentifier:@"MailComposerViewController"];
        [self.navigationController pushViewController:contr animated:YES];
    }
    if(indexPath.row == 4)
    {
        UIStoryboard *str = [UIStoryboard storyboardWithName:@"Main" bundle:nil];
        TermPrivacyAboutViewController *contr = [str instantiateViewControllerWithIdentifier:@"TermPrivacyAboutViewController"];
        [self.navigationController pushViewController:contr animated:YES];
        
        contr.result=@"Privacy Policy";

    }
    if(indexPath.row==3)
    {
        UIStoryboard *storyboard = [UIStoryboard storyboardWithName:@"Main" bundle:nil];
        ChangePasswordViewController *controller = [storyboard instantiateViewControllerWithIdentifier:@"ChangePasswordViewController"];
        [self.navigationController pushViewController:controller animated:YES];
    }

    
}
/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/
- (IBAction)pushForBack:(id)sender {
    UIStoryboard *str = [UIStoryboard storyboardWithName:@"Main" bundle:nil];
    SettingsViewController *contr = [str instantiateViewControllerWithIdentifier:@"Settings"];
    [self presentViewController:contr animated:YES completion:nil];
}

@end
