//
//  HistogramViewController.h
//  ChartJS
//
//  Created by Akash sharma on 22/03/17.
//  Copyright © 2017 Touchware. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface HistogramViewController : UIViewController

@end
