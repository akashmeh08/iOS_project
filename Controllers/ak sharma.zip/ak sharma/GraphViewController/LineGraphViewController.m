//
//  LineViewController.m
//  ChartJS
//
//  Created by Rahul Maithani on 20/03/17.
//  Copyright © 2017 Touchware. All rights reserved.
//

#import "LineGraphViewController.h"
#import "TWRChart.h"

@interface LineViewController ()
@property(strong, nonatomic) TWRChartView *chartView;
@end

@implementation LineViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    
    
    _chartView = [[TWRChartView alloc] initWithFrame:CGRectMake(0, 64, 320, 300)];
    _chartView.backgroundColor = [UIColor clearColor];
    
    // User interaction is disabled by default. You can enable it again if you want
    // _chartView.userInteractionEnabled = YES;
    
    // Load chart by using a ChartJS javascript file
    NSString *jsFilePath = [[NSBundle mainBundle] pathForResource:@"index" ofType:@"js"];
    [_chartView setChartJsFilePath:jsFilePath];
    
    // Add the chart view to the controller's view
    [self.view addSubview:_chartView];
//[self loadBarChart];
    [self loadLineChart];
    // Do any additional setup after loading the view.
}


- (void)loadLineChart {
    // Build chart data
    TWRDataSet *dataSet1 = [[TWRDataSet alloc] initWithDataPoints:@[@10, @15, @5, @15, @5]];
    TWRDataSet *dataSet2 = [[TWRDataSet alloc] initWithDataPoints:@[@5, @10, @5, @15, @10]];
    
    NSArray *labels = @[@"A", @"B", @"C", @"D", @"E"];
    
    TWRLineChart *line = [[TWRLineChart alloc] initWithLabels:labels
                                                     dataSets:@[dataSet1, dataSet2]
                                                     animated:NO];
    // Load data
    [_chartView loadLineChart:line];
}




- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
