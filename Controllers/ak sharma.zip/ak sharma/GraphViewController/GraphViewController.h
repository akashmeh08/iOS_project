//
//  GraphViewController.h
//  ChartJS
//
//  Created by Rahul Maithani on 20/03/17.
//  Copyright © 2017 Touchware. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface GraphViewController : UIViewController
- (IBAction)lineGraph:(id)sender;

@end
