//
//  MUserInfo.h
//  Mobiloitte
//

//  Copyright © 2017 Mobiloitte. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface MUserInfo : NSObject

@property(strong, nonatomic ) NSString *userFirstName;
@property(strong, nonatomic ) NSString *userLastName;
@property(strong, nonatomic ) NSString *userEmail;
@property(strong, nonatomic ) NSString *userMobileNumber;
@property(strong, nonatomic ) NSString *userPassword;
@property(strong, nonatomic ) NSString *userConfirmPassword;
@property(strong, nonatomic ) NSString *userGender;
@property(strong, nonatomic ) NSMutableArray *userSpecification;
@property(strong, nonatomic ) NSString *userDOB;
@property(strong, nonatomic ) NSString *userAppointmentTime;
@property(strong, nonatomic ) NSString *userCountry;
@property(strong, nonatomic ) NSString *userState;
@property(strong, nonatomic ) NSString *userBiography;

@property(strong,nonatomic) NSArray *nameArray;
@property(strong,nonatomic) NSArray *dobArray;
@property(strong,nonatomic) NSArray *phoneNo;
@property(strong,nonatomic) NSArray *imageView1;
@property(strong,nonatomic) NSString *rowIndex;
@end
