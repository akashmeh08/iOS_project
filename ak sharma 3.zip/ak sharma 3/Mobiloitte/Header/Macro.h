//
//  Macro.h
//  HealthCare
//
//

#ifndef Macro_h
#define Macro_h


/*******************************Constants*********************************/
#define TRIM_SPACE(str)                            [str stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]]
#define KTextField(tag)                            (UITextField*)[self.view viewWithTag:tag]
#define KButton(tag)                               (UIButton *)[self.view viewWithTag:tag]
#define KImageView(tag)                            (UIImageView *)[self.view viewWithTag:tag]
#define KLabel(tag)                                (UILabel*)[self.view viewWithTag:tag]
#define KTextView(tag)                             (UITextView*)[self.view viewWithTag:tag]
#define KSegmentControl(tag)                       (UISegmentedControl*)[self.toolBar viewWithTag:tag]
#define KActivityIndicatorView(tag)                (UIActivityIndicatorView*)[self.view viewWithTag:tag]

#define APPDELEGATE                                (AppDelegate*)[[UIApplication sharedApplication] delegate]
#define WIN_WIDTH                                  [[UIScreen mainScreen]bounds].size.width
#define WIN_HEIGHT                                 [[UIScreen mainScreen]bounds].size.height
#define NSUSERDEFAULT                              [NSUserDefaults standardUserDefaults]
#define TimeStamp                                  [NSString stringWithFormat:@"%.0f",[[NSDate date] timeIntervalSince1970]]


#define KApp_Placeholder_Color                     [UIColor colorWithRed:255.0/255.0 green:255.0/255.0 blue:255.0/255.0 alpha:0.90f]

#define KApp_Placeholder_DarkColor                 [UIColor colorWithRed:85.0/255.0 green:85.0/255.0 blue:85.0/255.0 alpha:0.70f]

#define KApp_Placeholder_LigthGrayColor                 [UIColor colorWithRed:184.0/255.0 green:184.0/255.0 blue:184.0/255.0 alpha:0.70f]


#define KApp_LightGreen                 [UIColor colorWithRed:0.0/255.0 green:150.0/255.0 blue:136.0/255.0 alpha:1.0f]
#define KApp_darkGreen                  [UIColor colorWithRed:0.0/255.0 green:104.0/255.0 blue:95.0/255.0 alpha:1.0f]

#define KApp_Available_Color              [UIColor colorWithRed:0.0/255.0 green:216.0/255.0 blue:215.0/255.0 alpha:1.0f]
#define KApp_Pending_Color                [UIColor colorWithRed:219.0/255.0 green:210.0/255.0 blue:68.0/255.0 alpha:1.0f]
#define KApp_Confirmed_Color                 [UIColor colorWithRed:0.0/255.0 green:156.0/255.0 blue:44.0/255.0 alpha:1.0f]
#define KApp_Cancelled_Color                 [UIColor colorWithRed:255.0/255.0 green:0.0/255.0 blue:18.0/255.0 alpha:1.0f]

#define KApp_Available_LightColor              [UIColor colorWithRed:0.0/255.0 green:216.0/255.0 blue:215.0/255.0 alpha:0.5f]
#define KApp_Pending_LightColor                [UIColor colorWithRed:219.0/255.0 green:210.0/255.0 blue:68.0/255.0 alpha:0.5f]
#define KApp_Confirmed_LightColor                 [UIColor colorWithRed:0.0/255.0 green:156.0/255.0 blue:44.0/255.0 alpha:0.5f]
#define KApp_Cancelled_LightColor                 [UIColor colorWithRed:255.0/255.0 green:0.0/255.0 blue:18.0/255.0 alpha:0.5f]


#define KApp_Image_BaseUrl                 [NSString stringWithFormat:@"%@/img",SERVICE_BASE_URL]



//**************************** LINKED IN API **************////////
#define LinkedInApiKey                              @"81hz55ahko8aya"
#define LinkedInSecretKey                           @"PBvccK8yvs8C3FDW"
#define LinkedInOAuthUserToken                      @"LinkedIn Oauth user token"
#define LinkedInOAuthUserSecret                     @"LinkedIn Oauth user secret"
#define NetworkErrorMessage                         @"Internet connection not available."

//************************************** Validations **************************************


#define KAlert_Empty_EmailOrMMCID                  @"Please enter email address."
#define KAlert_Empty_Password                      @"Please enter password."
#define KAlert_Invalid_Password                    @"Please enter a valid password."


#define KAlert_Empty_OldPassword                   @"Please enter old password."
#define KAlert_Invalid_OldPassword                 @"Please enter a valid old password."

#define KAlert_Empty_NewPassword                   @"Please enter new password."
#define KAlert_Invalid_NewPassword                 @"Please enter a valid new password."

#define KAlert_MinLength_EmailID @"Please enter minimum 6 characters email address."
#define KAlert_MaxLength_EmailID @"Please enter maximum 50 characters email address."

#define KAlert_MinLength_Password @"Please enter minimum 8 characters password."
#define KAlert_MaxLength_Password @"Please enter maximum 25 characters password"

#define KAlert_Empty_EmailID                       @"Please enter email ID."
#define KAlert_Invalid_EmailID                     @"Please enter valid email ID."

#define KAlert_Empty_OTP                           @"Please enter OTP."
#define KAlert_Invalid_OTP                         @"Please enter valid OTP."
#define KAlert_EmptyMessage                        @"Please enter your message."

#define KAlert_Empty_MobileNumber                  @"Please enter mobile number."
#define KAlert_Invalid_MobileNumber                @"Please enter a valid mobile number."

#define KAlert_Empty_ConfirmPassword               @"Please enter confirm password."
#define KAlert_MisMatch_Passwords                  @"Password and confirm password doesn't match."
#define KAlert_oldNewNotSame_Passwords             @"Old passord and new password cannot not   be same. "

#define KAlert_Empty_ChooseProfession              @"Please choice profession."
#define KAlert_Empty_EnterProfession               @"Please enter profession."
#define KAlert_Range_FirstName                     @"Please enter first name with atleast two characters."
#define KAlert_Range_LastName                      @"Please enter last name with atleast two characters."

#define KAlert_Empty_Name                          @"Please enter name."
#define KAlert_Empty_HospiatalName                    @"Please enter hospital name."
#define KAlert_Invalid_Name                          @"Please enter valid name."
#define KAlert_Empty_FirstName                     @"Please enter first name."
#define KAlert_Invalid_FirstName                   @"Please enter valid first name."
#define KAlert_Invalid_LastName                    @"Please enter valid last name."

#define KAlert_Empty_LastName                      @"Please enter last name."
#define KAlert_Empty_MartialStatus                 @"Please choose martial status."
#define KAlert_Empty_AadaarNumber                  @"Please enter aadhaar number."
#define KAlert_Invalid_AadaarNumber                @"Please enter valid aadhaar number."
#define KAlert_Empty_Dob                           @"Please select DOB."
#define KAlert_Empty_Gender                        @"Please choose gender."
#define KAlert_Empty_Nationality                   @"Please enter nationality."
#define KAlert_Invalid_Address                     @"Please enter a valid address."

#define KAlert_Empty_Address                       @"Please enter email address."
#define KAlert_Empty_Country                       @"Please select country."
#define KAlert_Empty_State                         @"Please select state."
#define KAlert_Empty_City                          @"Please select city."
#define KAlert_Empty_Pincode                       @"Please enter pincode."
#define KAlert_Invalid_Pincode                     @"Please enter valid pincode."
#define KAlert_Empty_RegisteredNumber              @"Please enter registration no."
#define KAlert_Empty_LicenseNumber                 @"Please enter license no."
#define KAlert_Invalid_LicenseNumber               @"Please enter valid license no."
#define KAlert_Empty_OtherMembership               @"Please enter other membership."

#define KAlert_Empty_Code                          @"Please enter code."
#define KAlert_Empty_HospitalCode                  @"Please enter hospital code."
#define KAlert_Empty_Fax                           @"Please enter fax no."
#define KAlert_Invalid_Fax                         @"Please enter valid fax no."
#define KAlert_Empty_ProfilePic                    @"Please choose profile image."
#define KAlert_Empty_Profession                    @"Please choose profession."
#define KAlert_Empty_Degree                        @"Please choose degree."
#define KAlert_Empty_Specality                     @"Please choose speciality."
#define KAlert_Empty_SubSpecality                  @"Please choose sub speciality."
#define KAlert_Empty_PracticeYear                  @"Please enter practice year."
#define KAlert_Invalid_PracticeYear                @"Please enter valid practice year."
#define KNotification_MoveToInbox                  @"notificationMoveToInbox"
#define KNotification_ClickOnFilter                @"notificationForClickOnFilter"
#define KNotification_ShowClear                    @"notificationForShowClearButton"
#define KNotification_CallApiOnClearSearch         @"notificationForCallApiOnClearSearch"

#define KNotification_ShowActiveClear              @"notificationForShowActiveClearButton"
#define KNotification_CallApiOnActiveClearSearchOrFilter         @"notificationForCallApiOnActiveClearSearchOrFilter"


#define KNotification_MoveToProfile                @"notificationMoveToProfile"

#define KNotification_FrameUp                     @"notificationFrameUp"
#define KNotification_FrameDown                   @"notificationFrameDown"

#define KNotification_UpdateProfile       @"notificationForUpdateProfile"


#define KNotification_MakePersonalInfoEditable       @"notificationForMakePersonalInfoEditable"
#define KNotification_MakePersonalInfoNonEditable    @"notificationForMakePersonalInfoNonEditable"
#define KNotification_MakeAddressInfoEditable       @"notificationForMakeAddressInfoEditable"
#define KNotification_MakeAddressInfoNonEditable    @"notificationForMakeAddressInfoNonEditable"
#define KNotification_MakeProfessionalInfoEditable       @"notificationForMakeProfessionalInfoEditable"
#define KNotification_MakeProfessionalInfoNonEditable    @"notificationForMakeProfessionalInfoNonEditable"

#define KNotification_ReloadInUserList       @"notificationForReloadInUserList"
#define KNotification_ReloadAddUserList      @"notificationForReloadAddUserList"

#define KNotification_ReloadPresentWorkingList       @"notificationForReloadPresentWorkingList"
#define KNotification_ReloadOtherFacilitiesList      @"notificationForReloadOtherFacilitiesList"

#define KAlert_Empty_Address1                      @"Please enter address line 1."
#define KAlert_Empty_Address2                      @"Please enter address line 2."
#define KAlert_Invalid_Address1                    @"Please enter a valid address line 1."
#define KAlert_Invalid_Address2                    @"Please enter a valid address line 2."
#define KAlert_Empty_PermanentAddress1             @"Please enter permanent address line 1."
#define KAlert_Empty_PermanentAddress2             @"Please enter permanent address line 2."
#define KAlert_Empty_MailingAddress                       @"Please either enter permanent address or check mailing address."
#define KAlert_Invalid_PermanentAddress1             @"Please enter a valid permanent address line 1."
#define KAlert_Invalid_PermanentAddress2             @"Please enter a valid permanent address line 2."
#define KAlert_Empty_MailingAddress                 @"Please either enter permanent address or check mailing address."

#define KAlert_NotAccept_TermsAndCondition         @"Please accept terms & condition."


#define KAlert_Empty_Amount                        @"Please enter amount."
#define KAlert_Invalid_Amount                        @"Please enter valid amount."

#define KAlert_Empty_ToRecipient                   @"Please enter recipient."
#define KAlert_Valid_ToRecipient                   @"Please enter valid recipient."
#define KAlert_Empty_Subject                       @"Please enter subject."
#define KAlert_Empty_Message                       @"Please enter message."
#define KAlert_Empty_Role                          @"Please choose role."

#define KAlert_Empty_StartDate                     @"Please select start date."
#define KAlert_Empty_EndDate                       @"Please select end date."
#define KAlert_Empty_Facility                      @"Please choose facility."
#define KAlert_Empty_StartTime                     @"Please choose start time."
#define KAlert_Empty_EndTime                       @"Please choose end time."
#define KAlert_Empty_PatientID                     @"Please choose Patient"
#define KAlert_Empty_SlotStatus                    @"Please choose slot status."
#define KAlert_Empty_EachSlotStatus                @"Please choose slot interval."
#define KAlert_Empty_AppointmentDuration           @"Please select atleast one day for  appointment duration."

#define KAlert_Empty_FacilityOrPatientHome         @"Please choose any facility or patient home."
#define kAlert_Invalid_MorningTimeSlots            @"Start time must be smaller than end time for morning slots."
#define kAlert_Invalid_MorningEndTimeSlots         @"End time must be greater than start time for morning slots."

#define kAlert_Invalid_AfterNoonTimeSlots          @"Start time must be smaller than end time for afternoon slots."
#define kAlert_Invalid_EndAfterNoonTimeSlots       @"End time must be greater than start time for afternoon slots."

#define KAlert_Empty_RepeatType                    @"Please choose repeat type."
#define KAlert_Empty_EndType                       @"Please choose end type."
#define KAlert_Empty_RepeatEveryDay                @"Please choose repeats every."
#define KAlert_Empty_StartOnDate                   @"Please choose start date."
#define KAlert_Empty_EndOnDate                     @"Please choose end date."
#define KAlert_Empty_EndAfterDay                   @"Please enter no. of days for end"
#define KAlert_Empty_weekOfTheDay                  @"Please tick any weekday."



#define KAlert_Invalid_StartDateEndDate            @"Start date must be smaller than end date."
#define KAlert_Invalid_EndDateStartDate            @"End date must be greater than start date."

#define KAlert_Empty_ReferTo                       @"Please enter refer to"
#define KAlert_Empty_ReferPhysician                @"Please enter physician name"
#define KAlert_Empty_ReferReason                   @"Please enter reason"
#define KAlert_Empty_ReferDate                     @"Please enter date"
#define KAlert_Valid_ReferPhysician                @"Please enter valid physician name"
#define KAlert_Valid_ReferTo                       @"Please enter valid refer to"
#define KAlert_Valid_ReferReason                   @"Please enter valid reason"

#define KAlert_Empty_ReportType                    @"Please select report type"
#define KAlert_Empty_ReportTitle                   @"Please select report title"
#define KAlert_Empty_SelectFOA                     @"Please select FOA"

#define KAlert_Empty_DateTime                      @"Please select date and time."



#endif /* Macro_h */
