//
//  NSObject+NSString.h
//  Mobiloitte
//
//  Copyright © 2017 Mobiloitte. All rights reserved.
//

#import <Foundation/Foundation.h>


@interface NSObject (NSString)

-(BOOL)isTextFieldBlank:(NSString *) textField;
-(BOOL)isValidEmailLength: (NSString *) emailId;

-(BOOL)isValidEmailId: (NSString *) emailId;
-(BOOL)isValidMobileNumber:(NSString *) mobileNumber;

-(BOOL)checkPasswordLength:(NSString *) password;

-(BOOL)comparePassword:(NSString*) password :(NSString*) confirmPassword;

-(BOOL)checkSpecification:(int ) count;



@end
