//
//  ChatTableViewCell.h
//  Mobiloitte
//
//  Created by Akash sharma on 18/03/17.
//  Copyright © 2017 Mobiloitte. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ChatTableViewCell : UITableViewCell
@property (strong, nonatomic) IBOutlet UILabel *labelItemName;
@property (weak, nonatomic) IBOutlet UILabel *recievedMessage;
@property (weak, nonatomic) IBOutlet UILabel *sentMessage;
@property (weak, nonatomic) IBOutlet UIImageView *receiverImage;
@property (weak, nonatomic) IBOutlet UIImageView *senderImage;


@end
