//
//  SegmentViewController.h
//  Mobiloitte
//
//  Created by Akash sharma on 17/03/17.
//  Copyright © 2017 Mobiloitte. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <MapKit/MapKit.h>
@interface SegmentViewController : UIViewController
{
    MKMapView *mapView;
}
@property (strong, nonatomic) IBOutlet MKMapView *mapView;
@property (weak, nonatomic) IBOutlet UISegmentedControl *segmentBtn;
@property (weak, nonatomic) IBOutlet UITableView *listTableView;

@end
