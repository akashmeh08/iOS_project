//
//  ProfileInfoViewController.h
//  Mobiloitte
//
//  Created by Akash sharma on 16/03/17.
//  Copyright © 2017 Mobiloitte. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "MUserInfo.h"
@interface ProfileInfoViewController : UIViewController
@property(strong, nonatomic)MUserInfo *userInfo;
@end
