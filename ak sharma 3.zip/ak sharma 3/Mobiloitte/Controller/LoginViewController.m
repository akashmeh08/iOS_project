//
//  LoginViewController.m
//  Mobiloitte
//

//

#import "LoginViewController.h"
#import "Utility.h"
#import "SignUpViewController.h"
#import "MUserInfo.h"
#import "HomeViewController.h"
#define MAXLENGTH 64
@interface LoginViewController ()
{
    int state;
}

@end

@implementation LoginViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
       //self.navigationItem.title = @"Login";
    [[self navigationController]setNavigationBarHidden:YES];
    [self customInit];
   
    state=0;
  
}
-(BOOL)textFieldShouldReturn:(UITextField *)textField
{
    if(textField.returnKeyType==UIReturnKeyNext)
    {
        UITextField *tf=(UITextField *)[self.view viewWithTag:textField.tag+1];
        [tf becomeFirstResponder];
    }
    else
    {
        [self.view endEditing:YES];
    }
    return YES;
    
}
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


#pragma mark - Helper Methods
-(void)customInit {
    [_emailTextField setKeyboardType:UIKeyboardTypeEmailAddress];
    UITapGestureRecognizer *tap = [[UITapGestureRecognizer alloc]   initWithTarget:self action:@selector(dismissKeyboard)];
    [self.view addGestureRecognizer:tap];  //to dismiss keyboard
}

-(void)dismissKeyboard {
    [self.view endEditing:YES];
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/
-(void)textFieldDidBeginEditing:(UITextField *)textField
{
    //  textField.autocapitalizationType = UITextAutocapitalizationTypeWords ;
    
    if(textField.frame.origin.y)
        [self animateTextField:textField up:YES];
     
}

- (void)textFieldDidEndEditing:(UITextField *)textField
{
    [self animateTextField:textField up:NO];
    
}
-(void)animateTextField:(UITextField*)textField up:(BOOL)up
{
    
    
    int movementDistance = -90; // tweak as needed
    
    const float movementDuration = 0.3f; // tweak as needed
    
    int movement = (up ? movementDistance : -movementDistance);
    
    [UIView beginAnimations: @"animateTextField" context: nil];
    [UIView setAnimationBeginsFromCurrentState: YES];
    [UIView setAnimationDuration: movementDuration];
    self.view.frame = CGRectOffset(self.view.frame, 0, movement);
    [UIView commitAnimations];
}



- (IBAction)onLoginBtnTouch:(id)sender {
    
    Utility *utility=[[Utility alloc]init];
    NSString *email=(NSString*)_emailTextField.text;
    NSString *password=(NSString*)_passwordTextField.text;
    NSString *result=[utility isValidate:email :password];
    NSLog(@"result = %@",result);
    if([result isEqualToString:@"Success"])
    {
        
        UIStoryboard* storyboard = [UIStoryboard storyboardWithName:@"Main" bundle:nil];
        HomeViewController * controller = [storyboard instantiateViewControllerWithIdentifier:@"HomeViewController"];
        [self.navigationController pushViewController:controller animated:YES ];
        
    }
    else
    {
        UIAlertController *alert = [UIAlertController alertControllerWithTitle:nil message:result preferredStyle:UIAlertControllerStyleAlert ];
        
        UIAlertAction *ok = [UIAlertAction actionWithTitle:@"Ok" style:UIAlertActionStyleDefault handler:nil];
        
        [alert addAction:ok];
        [self presentViewController:alert animated:YES completion:nil];
        
    }
}

- (IBAction)onSignUpBtnTouch:(id)sender {
    
    UIStoryboard* storyboard = [UIStoryboard storyboardWithName:@"Main" bundle:nil];
    SignUpViewController * controller = [storyboard instantiateViewControllerWithIdentifier:@"SignUpViewController"];
    
    [self.navigationController pushViewController:controller animated:YES ];
}


- (void)viewWillAppear:(BOOL)animated
{
    [self.navigationController setNavigationBarHidden:YES];
    
}
- (void)viewWillDisappear:(BOOL)animated
{
    [self.navigationController setNavigationBarHidden:YES];
}



- (BOOL)textField:(UITextField *) textField shouldChangeCharactersInRange:(NSRange)range replacementString:(NSString *)string {
    
    
    if([string isEqualToString:@""])
    {
        return YES;
    }
    if(textField.tag==101)
    {
    if(textField.text.length >=64)
   
        return NO;
    }
    else
    {
        if(textField.text.length >=16)
            
            return NO;
 
    }return YES;
}


- (IBAction)onCheckboxTouch:(id)sender {
    if(state==0)
    {
        state=1;
        
        [_checkboxBtn setBackgroundImage:[UIImage imageNamed:@"check"] forState:UIControlStateNormal];
        
    }
    else{
        
        state=0;
        [_checkboxBtn setBackgroundImage:[UIImage imageNamed:@"checkbox1"] forState:UIControlStateNormal];
    }
    
}



@end
