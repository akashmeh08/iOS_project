//
//  RatingViewController.m
//  Mobiloitte
//
//  Created by Akash sharma on 18/03/17.
//  Copyright © 2017 Mobiloitte. All rights reserved.
//

#import "RatingViewController.h"

@interface RatingViewController ()<UITextViewDelegate>
@property (weak, nonatomic) IBOutlet UIImageView *image1;
@property (weak, nonatomic) IBOutlet UIScrollView *scrollView;
@property (weak, nonatomic) IBOutlet UITextView *textView1;
@property (weak, nonatomic) IBOutlet UILabel *textCount;

@end

@implementation RatingViewController

- (void)viewDidLoad {
    [_scrollView setScrollEnabled:YES];
    [_scrollView setContentSize:CGSizeMake(414, 736)];

    [super viewDidLoad];
    self.navigationItem.title = @"Rate";
    // Do any additional setup after loading the view.
    [_scrollView setScrollEnabled:YES];
    [_scrollView setContentSize:CGSizeMake(414, 736)];
    
    _textView1.layer.cornerRadius = 5;
    _textView1.layer.borderColor =[[UIColor blackColor] CGColor];
    _textView1.layer.borderWidth = 1;
    
    self.image1.clipsToBounds = YES;
    _image1.layer.borderWidth=1;
    _image1.layer.cornerRadius = 50;
   
    
    

}

    
    - (BOOL)textView:(UITextView *)textView shouldChangeTextInRange:(NSRange)range replacementText:(NSString *)text
    {
        NSInteger newTextLength = [_textView1.text length] - range.length + [text length];
     
        if (newTextLength > 340)
        {
        
            return NO;
        }_textCount.text = [NSString stringWithFormat:@"%li", 340-newTextLength];

        return YES;
       
    }
    

    
    
    
    
    
    


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
