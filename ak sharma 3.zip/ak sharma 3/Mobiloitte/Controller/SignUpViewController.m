//
//  SignUpViewController.m
//  Mobiloitte
//
//  Copyright © 2017 Mobiloitte. All rights reserved.
//

#import "SignUpViewController.h"
#import "CustomTableViewCell.h"
#import "AlertController.h"
#import "OptionsPickerSheetView.h"
#import "DatePickerManager.h"
#import  "MUserInfo.h"
#import "NSObject+NSString.h"
#import "HomeViewController.h"
#import "SWRevealViewController.h"
#import "Macro.h"

@interface SignUpViewController ()<UITableViewDelegate,UITableViewDataSource,UITextFieldDelegate,UIImagePickerControllerDelegate,UINavigationControllerDelegate,UIToolbarDelegate>{
    
    MUserInfo *userInfo;
    
}
@property (weak, nonatomic) IBOutlet UIView *signup_headerView;
@property (weak, nonatomic) IBOutlet UIImageView *signup_imageView;
@property (weak, nonatomic) IBOutlet UITextField *biography;
@property (weak, nonatomic) IBOutlet UIButton *submit_button;
@property (weak, nonatomic) IBOutlet UITableView *signup_tableView;


@end

@implementation SignUpViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    self.navigationItem.title = @"SignUp";
    // Do any additional setup after loading the view.
    [self.navigationController setNavigationBarHidden:NO];
    
    UITapGestureRecognizer *selectProfileTapGesture = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(setProfilePicture)];
    selectProfileTapGesture.numberOfTapsRequired = 1;
    [self.signup_imageView addGestureRecognizer:selectProfileTapGesture];
        [self customInit];

    
}

#pragma mark - Helper Methods
-(void)customInit {
    
    
      [self.signup_imageView setUserInteractionEnabled:YES];
    
    _signup_imageView.layer.borderWidth = 1;
    _signup_imageView.layer.cornerRadius = 50;
    self.signup_imageView.clipsToBounds = YES;
    
    // Model Class variable init
    
    userInfo = [[MUserInfo alloc]init];
    userInfo.userFirstName=@"";
    userInfo.userLastName=@"";
    userInfo.userEmail=@"";
    userInfo.userMobileNumber=@"";
    userInfo.userPassword=@"";
    userInfo.userConfirmPassword=@"";
    userInfo.userGender=@"";
    userInfo.userDOB=@"";
    userInfo.userCountry=@"";
    userInfo.userAppointmentTime=@"";
    userInfo.userState=@"";
    
    userInfo.userSpecification=[[NSMutableArray  alloc]init];
    
    UITapGestureRecognizer *tap = [[UITapGestureRecognizer alloc]   initWithTarget:self action:@selector(dismissKeyboard)];
    [self.view addGestureRecognizer:tap];  //to dismiss keyboard
}

-(void)dismissKeyboard {
    [self.view endEditing:YES];
}

-(BOOL)textFieldShouldEndEditing:(UITextField *)textField
{
    switch (textField.tag)
    {
        case 50:
            userInfo.userFirstName = textField.text;
            break;
        case 51:
            userInfo.userLastName =  textField.text;
            break;
        case 52:
            userInfo.userEmail =  textField.text;
            break;
        case 53:
            userInfo.userMobileNumber = textField.text;
            break;
        case 54:
            userInfo.userPassword =  textField.text;
            break;
        case 55:
            userInfo.userConfirmPassword = textField.text;
            break;
            
        default:
            break;
    }
    NSLog(@"%@",userInfo.userFirstName);
    return true;
    
}
-(BOOL)textFieldShouldReturn:(UITextField *)textField
{
   
    if(textField.returnKeyType==UIReturnKeyNext)
    {
        UITextField *tf=(UITextField *)[self.view viewWithTag:textField.tag+1];
        [tf becomeFirstResponder];
    }
    else
    {
        [self.view endEditing:YES];
    }
    return YES;
}
- (BOOL)textField:(UITextField *)textField shouldChangeCharactersInRange:(NSRange)range replacementString:(NSString *)string
{
    if(textField.tag==53)
    {
        if([string isEqualToString:@""])
            return YES;
        if(textField.text.length>=10)
            return NO;
    }
    if (textField.text.length >=50 && range.length == 0)
    {
        return NO; // return NO to not change text
    }
    else
    {return YES;}
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (void)viewWillDisappear:(BOOL)animated
{
    [self.navigationController setNavigationBarHidden:YES];
}

- (void)onRadioBtnTouch:(UIButton *)sender {
    
    UIButton *maleBtn = (UIButton *)[self.view viewWithTag:1004];
    UIButton *femaleBtn = (UIButton *)[self.view viewWithTag:1005];
    
    NSLog(@"btn==%@",sender);
    
    switch (sender.tag) {
        case 1000:
             sender.selected = !sender.selected;
            NSLog(@"boll======%d",sender.selected);
            if(sender.selected == true)
            {
                [userInfo.userSpecification addObject:@"A"];
                NSLog(@"ewiuahriuaehsiruahseiushdiuas");
            }
            else
            {
                  [userInfo.userSpecification removeObject:@"A"];
            }
            break;
        case 1001:
            sender.selected = !sender.selected;

            if(sender.selected==true)
                [userInfo.userSpecification addObject:@"B"];
            else
                [userInfo.userSpecification removeObject:@"B"];
            
            break;
        case 1002:
            sender.selected = !sender.selected;
            if(sender.selected==true)
                [userInfo.userSpecification addObject:@"C"];
            else
                [userInfo.userSpecification removeObject:@"C"];
            
            
            break;
        case 1003:
            sender.selected = !sender.selected;

            if(sender.selected==true)
                [userInfo.userSpecification addObject:@"D"];
            else
                [userInfo.userSpecification removeObject:@"D"];
            
            break;
        case 1004:
            femaleBtn.selected = NO;
            maleBtn.selected = YES;
            
            userInfo.userGender=@"male";
            break;
        case 1005:
            femaleBtn.selected = YES;
            maleBtn.selected = NO;
            userInfo.userGender=@"female";
            break;
            
        default:
            break;
    }
    
}
- (void)onBtnTouch:(UIButton *)sender {
    
    switch (sender.tag) {
        case 2007:{
            [[DatePickerManager dateManager] showDatePicker:self andUIDateAndTimePickerMode:@"date" completionBlock:^(NSDate *date) {
                
                NSDate *today = [NSDate date];
                NSDateFormatter *df = [[NSDateFormatter alloc] init];
                [df setDateFormat:@"MM-dd-yyyy"];
                NSString *dateString = [df stringFromDate:today];
                dateString = [NSString stringWithFormat:@"%@",[df stringFromDate:date]];
                userInfo.userDOB =dateString;
                [self.signup_tableView reloadData];
                
            }];
           
        }
            break;
        case 2008:{
            [[DatePickerManager dateManager] showDatePicker:self andUIDateAndTimePickerMode:@"time" completionBlock:^(NSDate *date) {
                
                NSDate *today = [NSDate date];
                NSDateFormatter *df = [[NSDateFormatter alloc] init];
                [df setDateFormat:@"hh:mm a"];
                NSString *dateString = [df stringFromDate:today];
                dateString = [NSString stringWithFormat:@"%@",[df stringFromDate:date]];
                userInfo.userAppointmentTime =dateString;
                [self.signup_tableView reloadData];
                
            }];
        }
            break;
        case 2009:{
            [[OptionsPickerSheetView sharedPicker] showPickerSheetWithOptions:@[@"Afghanistan",@"Bhutan",@"Canada",@"Cyprus",@"India"] AndComplitionblock:^(NSString *selectedText, NSInteger selectedIndex) {
                
                userInfo.userCountry=selectedText;
                [self.signup_tableView reloadData];

                
            }];
        }
            break;
        case 2010:
        {
            
         
            
            if([userInfo.userCountry isEqual:@"India"])
            {
            [[OptionsPickerSheetView sharedPicker] showPickerSheetWithOptions:@[@"Arunachal Pradesh",@"Assam",@"Bihar",@"UP"] AndComplitionblock:^(NSString *selectedText, NSInteger selectedIndex) {
                
                userInfo.userState=selectedText;
                [self.signup_tableView reloadData];
            }];
            }
            else if ([userInfo.userCountry isEqual:@"Canada"])
            {
                [[OptionsPickerSheetView sharedPicker] showPickerSheetWithOptions:@[@"Alberta",@"British Columbia",@"Manitoba",@"Ontario"] AndComplitionblock:^(NSString *selectedText, NSInteger selectedIndex)
                {
                    
                    userInfo.userState=selectedText;
                    [self.signup_tableView reloadData];
                }];
                
            }
            
            else{
                [[OptionsPickerSheetView sharedPicker] showPickerSheetWithOptions:@[@""] AndComplitionblock:^(NSString *selectedText, NSInteger selectedIndex) {
                    
                    userInfo.userState=selectedText;
                    [self.signup_tableView reloadData];
                }];
            }
        }
            break;
            
        default:
            break;
    }
    
}
- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    return 70;
}
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    return 12;
}

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    
    return 1;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    
    CustomTableViewCell *cell = (CustomTableViewCell *)[tableView dequeueReusableCellWithIdentifier:@"CustomTableViewCellTextField" ];
    CustomTableViewCell *cell1 = (CustomTableViewCell *)[tableView dequeueReusableCellWithIdentifier:@"CustomTableViewCellButton" ];
    CustomTableViewCell *cell2 = (CustomTableViewCell *)[tableView dequeueReusableCellWithIdentifier:@"CustomTableViewCellSegment" ];
    
    cell.signup_textFieldButton.tag = 2000 + indexPath.row;
    [cell.signup_textFieldButton addTarget:self action:@selector(onBtnTouch:) forControlEvents:UIControlEventTouchUpInside];
    cell1.a_button.tag = 1000;
    cell1.b_button.tag = 1001;
    cell1.c_button.tag = 1002;
    cell1.d_button.tag = 1003;
    cell1.male_button.tag = 1004;
    cell1.female_button.tag = 1005;
    
    [cell1.a_button addTarget:self action:@selector(onRadioBtnTouch:) forControlEvents:UIControlEventTouchUpInside];
    [cell1.b_button addTarget:self action:@selector(onRadioBtnTouch:) forControlEvents:UIControlEventTouchUpInside];
    [cell1.c_button addTarget:self action:@selector(onRadioBtnTouch:) forControlEvents:UIControlEventTouchUpInside];
    [cell1.d_button addTarget:self action:@selector(onRadioBtnTouch:) forControlEvents:UIControlEventTouchUpInside];
    [cell1.male_button addTarget:self action:@selector(onRadioBtnTouch:) forControlEvents:UIControlEventTouchUpInside];
    [cell1.female_button addTarget:self action:@selector(onRadioBtnTouch:) forControlEvents:UIControlEventTouchUpInside];
    
    
    cell.signup_textFieldButton.hidden = YES;
    cell.downArrow_imageView.hidden = YES;
    cell.signup_textField.delegate = self;
    cell.signup_textField.secureTextEntry = NO;

    
    cell.signup_textField.tag = 50+indexPath.row;
    switch(indexPath.row)
    {
        case 0:
            cell.title_label.text = @"First Name";
            
            cell.signup_textField.placeholder = @"First Name";
            cell.signup_textField.autocapitalizationType=UITextAutocapitalizationTypeWords;
            cell.signup_textField.returnKeyType = UIReturnKeyNext;
            cell.signup_textField.text = userInfo.userFirstName;
            return cell;
            
        case 1:
            cell.title_label.text = @"Last Name";
            cell.signup_textField.placeholder = @"Last Name";
            cell.signup_textField.autocapitalizationType=UITextAutocapitalizationTypeWords;
            cell.signup_textField.returnKeyType = UIReturnKeyNext;
             cell.signup_textField.text = userInfo.userLastName;
            return cell;
        case 2:
            cell.title_label.text = @"Email Id";
            cell.signup_textField.placeholder = @"Email Id";
            [cell.signup_textField setKeyboardType:UIKeyboardTypeEmailAddress];
            cell.signup_textField.returnKeyType = UIReturnKeyNext;
             cell.signup_textField.text = userInfo.userEmail;
            return cell;
        case 3:
        {
            UIToolbar *toolbar = [[UIToolbar alloc] init];
            [toolbar setBarStyle:UIBarStyleBlackTranslucent];
            [toolbar sizeToFit];
            [toolbar setBarTintColor:[UIColor whiteColor]];
            UIBarButtonItem *doneButton = [[UIBarButtonItem alloc]initWithBarButtonSystemItem:UIBarButtonSystemItemDone target:self action:@selector(resignKeyboard)];
                        doneButton.tag= 3001;
            NSArray *itemArray = [NSArray arrayWithObjects:
                                  doneButton, nil];
            [toolbar setItems:itemArray];
            [cell.signup_textField setInputAccessoryView:toolbar];

            cell.title_label.text = @"Mobile";
            cell.signup_textField.placeholder = @"Mobile";
            [cell.signup_textField setKeyboardType:UIKeyboardTypeNumberPad];
            
            cell.signup_textField.returnKeyType = UIReturnKeyNext;
             cell.signup_textField.text = userInfo.userMobileNumber;
            return cell;
            
        }
        case 4:
            cell.title_label.text = @"Password";
            cell.signup_textField.placeholder = @"Password";
            cell.signup_textField.secureTextEntry=YES;
            cell.signup_textField.returnKeyType = UIReturnKeyNext;
             cell.signup_textField.text = userInfo.userPassword;
            return cell;
        case 5:
            cell.title_label.text = @"Confirm Password";
            cell.signup_textField.placeholder = @"Confirm Password";
            cell.signup_textField.secureTextEntry=YES;
            cell.signup_textField.returnKeyType = UIReturnKeyDone;
             cell.signup_textField.text = userInfo.userConfirmPassword;
            return cell;
        case 6:
            return cell1;
        case 7:
            cell.title_label.text = @"Date of Birth";
            cell.signup_textField.placeholder = @"DOB (MM-DD-YYYY)";
            cell.signup_textFieldButton.hidden = NO;
            cell.downArrow_imageView.hidden = NO;
            cell.signup_textField.text = userInfo.userDOB;
            return cell;
        case 8:
            cell.title_label.text = @"Appointment Time";
            cell.signup_textField.placeholder = @"Appointment Time (hh:mm am)";
            cell.signup_textFieldButton.hidden = NO;
            cell.downArrow_imageView.hidden = NO;
            cell.signup_textField.text = userInfo.userAppointmentTime;
            return cell;
        case 9:
            cell.title_label.text = @"Country";
            cell.signup_textField.autocapitalizationType=UITextAutocapitalizationTypeWords;
            cell.signup_textField.placeholder = @"Country";
            cell.signup_textFieldButton.hidden = NO;
            cell.downArrow_imageView.hidden = NO;
            cell.signup_textField.text = userInfo.userCountry;
            return cell;
        case 10:
            cell.title_label.text = @"State";
            cell.signup_textField.autocapitalizationType=UITextAutocapitalizationTypeWords;
            cell.signup_textField.placeholder = @"State";
            cell.signup_textFieldButton.hidden = NO;
            cell.downArrow_imageView.hidden = NO;
            cell.signup_textField.text = userInfo.userState;
            return cell;
        case 11:
            return cell2;
    }
    return nil;
    
}

-(void)resignKeyboard
{
    [self.view endEditing:YES];
}
#pragma mark - UIImagePicker Delegate method

- (void)imagePickerControllerDidCancel:(UIImagePickerController *)picker {
    [picker dismissViewControllerAnimated:YES completion:NULL];
}

- (void)imagePickerController:(UIImagePickerController *)picker didFinishPickingImage:(UIImage *)image editingInfo:(NSDictionary *)editingInfo {
    
    
    [self.signup_imageView setImage:image];
    
    
    [picker dismissViewControllerAnimated:YES completion:NULL];
}

//Action sheet cases to select from gallary or camera
- (void)setProfilePicture
{
    [AlertController actionSheet:@"" message:@"Please select image source." andButtonsWithTitle:@[@"Take Photo",@"Choose Photo"] dismissedWith:^(NSInteger index, NSString *buttonTitle)
     {
         
         UIImagePickerController *profileImagePicker = [[UIImagePickerController alloc] init];
         profileImagePicker.delegate = self;
         profileImagePicker.allowsEditing = YES;
         
         if (!index)
         {
             if ([UIImagePickerController isSourceTypeAvailable:UIImagePickerControllerSourceTypeCamera])
             {
                 profileImagePicker.sourceType =  UIImagePickerControllerSourceTypeCamera;
                 [self presentViewController:profileImagePicker animated:YES completion:NULL];
             }
             else
             {
                 [AlertController title:@"" message:@"Camera is not available."];
             }
         }
         else if (index == 1)
         {
             [self presentViewController:profileImagePicker animated:YES completion:NULL];
         }
     }];
}


- (IBAction)onSubmitBtnTouch:(id)sender {
    
        [self isValidateTextField];
}
-(void)isValidateTextField
{
    NSString *result = @"Successfully Registered";
    
    if([userInfo.userFirstName isEqualToString:@""]  )
    {
        NSLog(@"jghjkhjk");
        result = KAlert_Invalid_FirstName;
    }
    else if ([userInfo.userLastName isEqualToString:@""] )
    {
        result = KAlert_Invalid_LastName;
    }
    else if ([userInfo.userEmail isEqualToString:@""] )
    {
        result= KAlert_Empty_Address;
    }
    else if (![userInfo.userEmail isValidEmailId: userInfo.userEmail] )
    {
        result= @"Please enter valid email id.";
    }
    else if ([userInfo.userMobileNumber isValidMobileNumber: userInfo.userMobileNumber] )
    {
        result= KAlert_Invalid_MobileNumber;
    }
    else if ([userInfo.userPassword isEqualToString:@""] )
    {
        result= @"Please enter password.";
    }
    else if (userInfo.userPassword.length<6 )
    {
        result=@"Please enter minimum 6 characters password.";
    }
    else if ([userInfo.userConfirmPassword isEqualToString:@""] )
    {
        result=@"Please enter confirm password.";
    }
    else if (userInfo.userConfirmPassword.length<6 )
    {
        result=@"Please enter minimum 6 characters confirm password.";
    }
    else if ([userInfo.userPassword comparePassword: userInfo.userPassword : userInfo.userConfirmPassword] )
    {
        result=@"Please enter confirm password same as password";
    }
    else if ([userInfo.userGender isEqualToString:@""])
    {
        result=@"Please select gender.";
    }
    else if ([userInfo.userSpecification count] < 2)
    {
        result=@"Please select atleast 2 specification.";
    }
    else if ([userInfo.userDOB isEqualToString:@""])
    {
        result=@"Please select date of birth.";
    }
    else if ([userInfo.userAppointmentTime isEqualToString:@""])
    {
        result=@"Please select appointment time.";
    }
    else if ([userInfo.userCountry isEqualToString:@""])
    {
        result=@"Please select country.";
    }
    else if ([userInfo.userState isEqualToString:@""])
    {
        result=@"Please select state.";
    }

    if([result isEqualToString:@"Successfully Registered"])
    {
//        UIAlertController *alert = [UIAlertController alertControllerWithTitle:nil message:result preferredStyle:UIAlertControllerStyleAlert ];
//        UIAlertAction *ok = [UIAlertAction actionWithTitle:@"Ok" style:UIAlertActionStyleDefault handler:nil];
//        [alert addAction:ok];
//        [self presentViewController:alert animated:YES completion:nil];
        
        UIStoryboard *storyboard = [UIStoryboard storyboardWithName:@"Main" bundle:nil];
        SWRevealViewController *controller = [storyboard instantiateViewControllerWithIdentifier:@"HomeViewController"];
        [self.navigationController pushViewController:controller animated:YES];

    }
    else
    {
        UIAlertController *alert = [UIAlertController alertControllerWithTitle:nil message:result preferredStyle:UIAlertControllerStyleAlert ];
        UIAlertAction *ok = [UIAlertAction actionWithTitle:@"Ok" style:UIAlertActionStyleDefault handler:nil];
        [alert addAction:ok];
        [self presentViewController:alert animated:YES completion:nil];

    }



}
@end
