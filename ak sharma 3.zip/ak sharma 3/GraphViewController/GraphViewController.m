//
//  GraphViewController.m
//  ChartJS
//
//  Created by Rahul Maithani on 20/03/17.
//  Copyright © 2017 Touchware. All rights reserved.
//

#import "GraphViewController.h"
#import "LineGraphViewController.h"
#import "HistogramViewController.h"
#import "PieGraphViewController.h"
@interface GraphViewController ()
- (IBAction)histographButton:(id)sender;


@end

@implementation GraphViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}
- (IBAction)pieGraphButton:(id)sender {
    UIStoryboard *str = [UIStoryboard storyboardWithName:@"Main" bundle:nil];
    PieGraphViewController *contr = [str instantiateViewControllerWithIdentifier:@"PieGraphViewController"];
    [self presentViewController:contr animated:YES completion:nil];
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

- (IBAction)lineGraph:(id)sender {
    UIStoryboard *str = [UIStoryboard storyboardWithName:@"Main" bundle:nil];
    LineViewController *contr = [str instantiateViewControllerWithIdentifier:@"LineViewController"];
    [self presentViewController:contr animated:YES completion:nil];
}


- (IBAction)histographButton:(id)sender {
    UIStoryboard *str = [UIStoryboard storyboardWithName:@"Main" bundle:nil];
    HistogramViewController *contr = [str instantiateViewControllerWithIdentifier:@"HistogramViewController"];
    [self presentViewController:contr animated:YES completion:nil];
}

- (IBAction)histogramButton:(id)sender {
}
@end
