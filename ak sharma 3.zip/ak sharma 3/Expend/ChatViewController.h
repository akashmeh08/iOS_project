//
//  ChatViewController.h
//  NewScreensTest
//
//  Created by Ram Chandra on 18/03/17.
//  Copyright © 2017 Ram Chandra. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ChatViewController : UIViewController

@end
