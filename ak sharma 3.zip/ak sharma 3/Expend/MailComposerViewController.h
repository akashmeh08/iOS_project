//
//  MailComposerViewController.h
//  Mobiloitte
//
//  Created by Mobiloitte on 21/03/17.
//  Copyright © 2017 Mobiloitte. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface MailComposerViewController : UIViewController
@property (strong, nonatomic) IBOutlet UITextField *fromMailComposerTextField;
@property (strong, nonatomic) IBOutlet UITextField *toMailComposerTextField;
@property (strong, nonatomic) IBOutlet UITextField *subjecMailComposerTextField;
@property (strong, nonatomic) IBOutlet UITextView *comaposeMailTextView;

@end
