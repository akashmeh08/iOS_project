//
//  ChangePasswordViewController.m
//  Mobiloitte
//
//  Created by Mobiloitte on 18/03/17.
//  Copyright © 2017 Mobiloitte. All rights reserved.
//

#import "ChangePasswordViewController.h"


@interface ChangePasswordViewController ()

- (IBAction)changePasswordBtn:(id)sender;
@end

@implementation ChangePasswordViewController

#pragma mark-View Life Cycle Method
- (void)viewDidLoad {
    [super viewDidLoad];
      self.navigationItem.title = @"Change Password";
    // Do any additional setup after loading the view.
    [self.navigationController setNavigationBarHidden:NO];
    UITapGestureRecognizer *tap = [[UITapGestureRecognizer alloc]   initWithTarget:self action:@selector(dismissKeyboard)];
    [self.view addGestureRecognizer:tap];
    _oldPasswordTextField.layer.sublayerTransform=CATransform3DMakeTranslation(10.0f, 0.0f, 0.0f);
    _passText.layer.sublayerTransform=CATransform3DMakeTranslation(10.0f, 0.0f, 0.0f);
    _changePassswordTextField.layer.sublayerTransform=CATransform3DMakeTranslation(10.0f, 0.0f, 0.0f);
    
    
  }



-(void)dismissKeyboard {
    [self.view endEditing:YES];
}
#pragma mark-TextField Method
-(BOOL)textFieldShouldBeginEditing:(UITextField *)textField {
    
    return YES;
}
-(void)textFieldDidBeginEditing:(UITextField *)textField
{
    
    //  textField.autocapitalizationType = UITextAutocapitalizationTypeWords ;
    
    
    if(textField.frame.origin.y)
        [self animateTextField:textField up:YES];
    
    
}
- (void)textFieldDidEndEditing:(UITextField *)textField
{
    [self animateTextField:textField up:NO];
    
}
-(void)animateTextField:(UITextField*)textField up:(BOOL)up
{
    
    
    int movementDistance = -100; // tweak as needed
    
    const float movementDuration = 0.3f; // tweak as needed
    
    int movement = (up ? movementDistance : -movementDistance);
    
    [UIView beginAnimations: @"animateTextField" context: nil];
    [UIView setAnimationBeginsFromCurrentState: YES];
    [UIView setAnimationDuration: movementDuration];
    self.view.frame = CGRectOffset(self.view.frame, 0, movement);
    [UIView commitAnimations];
}


- (BOOL)textFieldShouldEndEditing:(UITextField *)textField {
    
    return YES;
}
- (BOOL)textField:(UITextField *)textField shouldChangeCharactersInRange:(NSRange)range replacementString:(NSString *)string
{
    if (textField.text.length >=30 && range.length == 0)
    {
        return NO; // return NO to not change text
    }
    else
    {return YES;}
}
-(BOOL)textFieldShouldReturn:(UITextField *)textField
{
    if(textField.returnKeyType==UIReturnKeyNext)
    {
        UITextField *tf=(UITextField *)[self.view viewWithTag:textField.tag+1];
        [tf becomeFirstResponder];
    }
    else
    {
        [self.view endEditing:YES];
    }
    return YES;
}

#pragma mark-Memory Warning Method
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/
#pragma mark- Change Password Method
- (IBAction)changePasswordBtn:(id)sender {
    NSString *result=@"Change Passsword";
    if([_oldPasswordTextField.text isEqualToString:@""])
    {
        result=@"Please enter old password.";
        UIAlertController *alert = [UIAlertController alertControllerWithTitle:nil message:result preferredStyle:UIAlertControllerStyleAlert ];
        UIAlertAction *ok = [UIAlertAction actionWithTitle:@"Ok" style:UIAlertActionStyleDefault handler:nil];
        [alert addAction:ok];
        [self presentViewController:alert animated:YES completion:nil];

    }
    else if([_passText.text isEqualToString:@""])
    {
        result=@"Please enter new password.";
       UIAlertController *alert = [UIAlertController alertControllerWithTitle:nil message:result preferredStyle:UIAlertControllerStyleAlert ];
        UIAlertAction *ok = [UIAlertAction actionWithTitle:@"Ok" style:UIAlertActionStyleDefault handler:nil];
        [alert addAction:ok];
        [self presentViewController:alert animated:YES completion:nil];
        
    }
    else if([_changePassswordTextField.text isEqualToString:@""])
    {
        result=@"Please enter  confirm password.";
        UIAlertController *alert = [UIAlertController alertControllerWithTitle:nil message:result preferredStyle:UIAlertControllerStyleAlert ];
        UIAlertAction *ok = [UIAlertAction actionWithTitle:@"Ok" style:UIAlertActionStyleDefault handler:nil];
        [alert addAction:ok];
        [self presentViewController:alert animated:YES completion:nil];
        
    }
    else if(![_passText.text isEqualToString:_changePassswordTextField.text])
    {
        result=@"Please enter  confirm password as new password.";
        UIAlertController *alert = [UIAlertController alertControllerWithTitle:nil message:result preferredStyle:UIAlertControllerStyleAlert ];
        UIAlertAction *ok = [UIAlertAction actionWithTitle:@"Ok" style:UIAlertActionStyleDefault handler:nil];
        [alert addAction:ok];
        [self presentViewController:alert animated:YES completion:nil];
        
    }
    else{
        result=@"Password is change.";
        UIAlertController *alert = [UIAlertController alertControllerWithTitle:nil message:result preferredStyle:UIAlertControllerStyleAlert ];
        UIAlertAction *ok = [UIAlertAction actionWithTitle:@"Ok" style:UIAlertActionStyleDefault handler:nil];
        [alert addAction:ok];
        [self presentViewController:alert animated:YES completion:nil];
    }

    
    

}
@end
