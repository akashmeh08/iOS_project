//
//  BoopsViewController.h
//  Mobiloitte
//
//  Created by Mobiloitte on 20/03/17.
//  Copyright © 2017 Mobiloitte. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface BoopsViewController : UIViewController
@property (strong, nonatomic) IBOutlet UIBarButtonItem *barButton;
@property (strong, nonatomic) IBOutlet UITableView *boopstableView;

@end
