//
//  PathMenuVC.m
//  Mobiloitte
//
//  Created by Akash Mehrotra on 18/03/17.
//  Copyright © 2017 Mobiloitte. All rights reserved.
//

#import "PathMenuVC.h"

@implementation PathMenuVC

/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect {
    // Drawing code
}
*/

@end
