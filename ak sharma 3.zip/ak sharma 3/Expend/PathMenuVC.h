//
//  PathMenuVC.h
//  Mobiloitte
//
//  Created by Akash Mehrotra on 18/03/17.
//  Copyright © 2017 Mobiloitte. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface PathMenuVC : UIView

@end
