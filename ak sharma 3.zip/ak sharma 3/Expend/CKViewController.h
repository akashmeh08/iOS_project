#import <UIKit/UIKit.h>
#import <Foundation/Foundation.h>
#import <QuartzCore/QuartzCore.h>

@interface CKViewController : UIViewController

@property (weak, nonatomic) IBOutlet UIBarButtonItem *menuBarBtn;
@end
