//
//  EandCViewController.m
//  EandC
//
//  Created by Mobiloitte on 18/03/17.
//  Copyright © 2017 Mobiloitte. All rights reserved.
//

#import "EandCViewController.h"
#import "SWRevealViewController.h"
#import "CustomTableViewCell.h"

@interface EandCViewController ()

@end

@implementation EandCViewController
#pragma mark-View Life Cycle Method
@synthesize tableView;
- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    SWRevealViewController *revealViewController =self.revealViewController; //[[SWRevealViewController alloc]init];
     self.tableView.tableFooterView=[[UIView alloc]initWithFrame:CGRectZero];
    if ( revealViewController )
    {
        NSLog(@"hkhdkjsf");
        [self.barButton setTarget:self.revealViewController];
        [self.barButton setAction: @selector( revealToggle: )];
        [self.view addGestureRecognizer:self.revealViewController.panGestureRecognizer];
    }
    cell0SubMenuItemsArray = @[@"Arunachal Pradesh",@"Assam",@"Bihar",@"UP"];
    cell1SubMenuItemsArray = @[@"Arunachal Pradesh",@"Assam",@"Bihar",@"UP"];

   // [self loadCellInfo];
    
}
- (void)viewDidAppear:(BOOL)animated
{
    [super viewDidAppear:animated];
    
    [self.view setNeedsLayout];
}

- (void)viewDidLayoutSubviews
{
    [super viewDidLayoutSubviews];
}

#pragma mark-Memory Warning Method
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}
# pragma mark - UITableView Delegate and Datasource

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    if (section == 0)
    {
        int cellCount = 2; // Default count - if not a single cell is expanded
        
        if (isSection0Cell0Expanded)
        {
            cellCount += [cell0SubMenuItemsArray count];
        }
        
        return cellCount;
    }
    
    return 0;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    static NSString *strCellId = @"CellId";
    
    UITableViewCell *cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleSubtitle reuseIdentifier:strCellId];
    cell.selectionStyle = UITableViewCellSelectionStyleNone;
    cell.accessoryType = UITableViewCellAccessoryNone;
    
    if ([cell respondsToSelector:@selector(setPreservesSuperviewLayoutMargins:)])
    {
        [cell setPreservesSuperviewLayoutMargins:NO];
    }
    
    if ([cell respondsToSelector:@selector(setLayoutMargins:)])
    {
        [cell setLayoutMargins:UIEdgeInsetsZero];
    }
    
    if (indexPath.section == 0)
    {
        if (indexPath.row == 0)
        {
            cell.textLabel.text = @"India";
           // cell.textLabel.font = [ systemFontSize:15];
            
            UIImageView *accessoryImageView = [[UIImageView alloc] initWithFrame:CGRectMake(0, 0, 15, 15)];
            
            if (isSection0Cell0Expanded) // Set accessory view according to cell state - EXPANDED / NOT EXPANDED
            {
                accessoryImageView.image = [UIImage imageNamed:@"images-4"];
                //cell.detailTextLabel.text = @"Status : Expanded";
            }
            else
            {
                accessoryImageView.image = [UIImage imageNamed:@"images-5"];
                //cell.detailTextLabel.text = @"Status : Not Expanded";
            }
            
            cell.accessoryView = accessoryImageView;
        }
        
        else
        {
            if (isSection0Cell0Expanded && [cell0SubMenuItemsArray count] >= indexPath.row) // Check Expanded status and do the necessary changes
            {
                cell.textLabel.text = [NSString stringWithFormat:@"%@", [cell0SubMenuItemsArray objectAtIndex:indexPath.row - 1]];
                cell.textLabel.font = [UIFont systemFontOfSize:13];
                cell.backgroundColor = [UIColor whiteColor];
            }
            else
            {
                cell.textLabel.text = @"Other Names";
                cell.textLabel.font = [UIFont systemFontOfSize:15];
                
                
            }
        }
    }
    
    return cell;
}

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    return 1;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    if (indexPath.row == 0)
    {
        // Change status of a cell reload table
        
        isSection0Cell0Expanded = !isSection0Cell0Expanded;
        
        if (isSection0Cell0Expanded)
        {
            NSArray *cells = [NSArray arrayWithObjects:
                              [NSIndexPath indexPathForRow:1 inSection:0],
                              [NSIndexPath indexPathForRow:2 inSection:0],
                              [NSIndexPath indexPathForRow:3 inSection:0],
                              [NSIndexPath indexPathForRow:4 inSection:0],
                              nil];
            
            [CATransaction begin];
            
            [CATransaction setCompletionBlock:^{
                [self.tableView reloadData];
            }];
            
            [self.tableView beginUpdates];
            [self.tableView insertRowsAtIndexPaths:cells withRowAnimation:UITableViewRowAnimationFade];
            [self.tableView endUpdates];
            
            [CATransaction commit];
            
        }
        else
        {
            NSArray *cells = [NSArray arrayWithObjects:
                              [NSIndexPath indexPathForRow:1 inSection:0],
                              [NSIndexPath indexPathForRow:2 inSection:0],
                              [NSIndexPath indexPathForRow:3 inSection:0],
                              [NSIndexPath indexPathForRow:4 inSection:0],
                              nil];
            
            [CATransaction begin];
            
            [CATransaction setCompletionBlock:^{
                [self.tableView reloadData];
            }];
            
            [self.tableView beginUpdates];
            [self.tableView deleteRowsAtIndexPaths:cells withRowAnimation:UITableViewRowAnimationFade];
            [self.tableView endUpdates];
            
            [CATransaction commit];
        }
    }
}

/*
#pragma mark-TableView Method 
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    if(visibleRows.count > 0)
    {
        return visibleRows.count;
    }
    else
    return 0;
    
}
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    NSDictionary *currentCell = [self getCurrentCellInfo:indexPath];
    
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"reuse"];
    if(cell == nil)
    {
        cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:@"reuse"];
       // cell.accessoryType = UITableViewCellAccessoryDisclosureIndicator;
        
    }
    
    cell.textLabel.text = [currentCell valueForKey:@"cellTitle"];
    
    return cell;
}
-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    NSInteger tappedRow = [visibleRows[indexPath.row] intValue];
    BOOL shouldExpandAndShow;
    if([[cellInfo[tappedRow] valueForKey:@"isExpandable"] boolValue])
    {
        shouldExpandAndShow = false;
        if(![[cellInfo[tappedRow] valueForKey:@"isExpanded"] boolValue])
        {
            shouldExpandAndShow = true;
        }
    }
    [cellInfo[tappedRow] setValue:[NSNumber numberWithBool:shouldExpandAndShow] forKey:@"isExpanded"];
    for( long int i = tappedRow+1;i <=(tappedRow + [[cellInfo[tappedRow] valueForKey:@"additionalRows"] intValue]); i++)
    {
      [cellInfo[i] setValue:[NSNumber numberWithBool:shouldExpandAndShow] forKey:@"isVisible"];
    }
    [self getVisibleRows];
    [self.tableView reloadSections: [NSIndexSet indexSetWithIndex:0] withRowAnimation:UITableViewRowAnimationFade];
}

-(void)loadCellInfo
{
    if([[NSFileManager defaultManager] fileExistsAtPath:[[NSBundle mainBundle] pathForResource:@"CellInfo-2" ofType:@"plist"]])
    {
        cellInfo = [NSMutableArray arrayWithContentsOfFile:[[NSBundle mainBundle] pathForResource:@"CellInfo-2" ofType:@"plist"]];

    }
    [self getVisibleRows];
    [self.tableView reloadData];
}
-(void)getVisibleRows
{
    visibleRows = [[NSMutableArray alloc] init];
    int i;
    for(i = 0;i < cellInfo.count;i++)
    {
        if([[cellInfo[i] valueForKey:@"isVisible"] boolValue])
            
        {
            [visibleRows addObject:[NSNumber numberWithInt:i]];
        }
    }
}
-(NSDictionary *)getCurrentCellInfo : (NSIndexPath *)indexPath
{
    NSDictionary *cellDictionary = cellInfo[[visibleRows[indexPath.row] intValue]];
    
    return cellDictionary;
}*/
/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
