//
//  ExpandableTableViewController.h
//  ExpandableTable
//

//

#import <UIKit/UIKit.h>

@interface ExpandableTableViewController : UITableViewController

@property(nonatomic,strong) NSArray *items;
@property (nonatomic, retain) NSMutableArray *itemsInTable;
@property (strong, nonatomic) IBOutlet UITableView *menuTableView;
@property (weak, nonatomic) IBOutlet UIButton *press;

@end
