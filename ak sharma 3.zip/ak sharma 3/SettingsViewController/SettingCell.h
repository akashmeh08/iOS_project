//
//  CustomTableViewCell.h
//  Setting
//
//  Created by Abhishek Tripathi on 3/18/17.
//  Copyright © 2017 Mobiloitte. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface SettingCell : UITableViewCell
@property (strong, nonatomic) IBOutlet UILabel *labelItemName;

@end
